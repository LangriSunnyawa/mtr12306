package com.mtr12306.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import com.mtr12306.Mtr12306;
import com.mtr12306.TicketingManager;
import com.mtr12306.block.ModBlocks;
import com.mtr12306.block.TicketGateBlock;
import com.mtr12306.block.TicketGateBlockEntity;
import com.mtr12306.data.Checkpoint;
import com.mtr12306.data.ServiceStop;
import com.mtr12306.data.Station;
import com.mtr12306.data.Ticket;
import com.mtr12306.data.TicketingException;
import com.mtr12306.data.TrainService;
import com.mtr12306.fares.FareAccount;
import com.mtr12306.web.WebServer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3965;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * /mtr12306 管理命令 与 /ticket 乘客命令。
 */
public final class TicketCommands {
	private TicketCommands() {
	}

	public static void register() {
		CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
			registerAdmin(dispatcher);
			registerPlayer(dispatcher);
		});
	}

	private static void registerAdmin(final CommandDispatcher<class_2168> dispatcher) {
		final LiteralArgumentBuilder<class_2168> root = class_2170.method_9247("mtr12306")
				.requires(source -> source.method_9259(2));

		root.then(class_2170.method_9247("help").executes(TicketCommands::help));

		root.then(class_2170.method_9247("web")
				.then(class_2170.method_9247("start").executes(TicketCommands::webStart))
				.then(class_2170.method_9247("stop").executes(TicketCommands::webStop))
				.then(class_2170.method_9247("info").executes(TicketCommands::webInfo)));

		root.then(class_2170.method_9247("station")
				.then(class_2170.method_9247("add")
						.then(class_2170.method_9244("name", StringArgumentType.string())
								.executes(context -> addStation(context, ""))
								.then(class_2170.method_9244("platforms", StringArgumentType.string())
										.executes(context -> addStation(context,
												StringArgumentType.getString(context, "platforms"))))))
				.then(class_2170.method_9247("list").executes(TicketCommands::listStations))
				.then(class_2170.method_9247("remove")
						.then(class_2170.method_9244("id", StringArgumentType.word()).executes(TicketCommands::removeStation))));

		root.then(class_2170.method_9247("checkpoint")
				.then(class_2170.method_9247("add")
						.then(class_2170.method_9244("station", StringArgumentType.word())
								.then(class_2170.method_9244("name", StringArgumentType.string())
										.executes(context -> addCheckpoint(context, ""))
										.then(class_2170.method_9244("platforms", StringArgumentType.string())
												.executes(context -> addCheckpoint(context,
														StringArgumentType.getString(context, "platforms")))))))
				.then(class_2170.method_9247("list").executes(TicketCommands::listCheckpoints))
				.then(class_2170.method_9247("remove")
						.then(class_2170.method_9244("id", StringArgumentType.word())
								.executes(TicketCommands::removeCheckpoint))));

		root.then(class_2170.method_9247("service")
				.then(class_2170.method_9247("list").executes(TicketCommands::listServices))
				.then(class_2170.method_9247("remove")
						.then(class_2170.method_9244("number", StringArgumentType.word())
								.executes(TicketCommands::removeService))));

		// 闸机判定自检：/mtr12306 gate simulate <x> <y> <z> <玩家> <in|out> [consume] [apply]
		final LiteralArgumentBuilder<class_2168> simulateNode = class_2170.method_9247("simulate")
				.then(class_2170.method_9244("x", IntegerArgumentType.integer())
						.then(class_2170.method_9244("y", IntegerArgumentType.integer())
								.then(class_2170.method_9244("z", IntegerArgumentType.integer())
										.then(class_2170.method_9244("player", StringArgumentType.word())
												.then(simulateDirectionNode())))));

		final LiteralArgumentBuilder<class_2168> mockPassNode = class_2170.method_9247("mockpass")
				.then(class_2170.method_9244("x", IntegerArgumentType.integer())
						.then(class_2170.method_9244("y", IntegerArgumentType.integer())
								.then(class_2170.method_9244("z", IntegerArgumentType.integer())
										.then(class_2170.method_9244("player", StringArgumentType.word())
												.then(class_2170.method_9244("direction", StringArgumentType.word())
														.executes(TicketCommands::mockPass))))));

		root.then(class_2170.method_9247("gate")
				.then(class_2170.method_9247("bind")
						.then(class_2170.method_9244("checkpoint", StringArgumentType.word())
								.then(class_2170.method_9244("mode", StringArgumentType.word())
										.executes(TicketCommands::bindGateWithMode))
								.executes(TicketCommands::bindGate)))
				.then(class_2170.method_9247("unbind").executes(TicketCommands::unbindGate))
				.then(class_2170.method_9247("info").executes(TicketCommands::gateInfo))
				.then(simulateNode)
				.then(mockPassNode));

		root.then(class_2170.method_9247("boarding")
				.then(class_2170.method_9247("list").executes(TicketCommands::listBoarding))
				.then(class_2170.method_9247("open")
						.then(class_2170.method_9244("service", StringArgumentType.word())
								.then(class_2170.method_9244("station", StringArgumentType.word())
										.executes(context -> openBoarding(context, 15))
										.then(class_2170.method_9244("minutes", IntegerArgumentType.integer(1, 600))
												.executes(context -> openBoarding(context,
														IntegerArgumentType.getInteger(context, "minutes")))))))
				.then(class_2170.method_9247("close")
						.then(class_2170.method_9244("service", StringArgumentType.word())
								.then(class_2170.method_9244("station", StringArgumentType.word())
										.executes(TicketCommands::closeBoarding)))));

		final LiteralArgumentBuilder<class_2168> buy = class_2170.method_9247("buy")
				.then(class_2170.method_9244("player", StringArgumentType.word())
						.then(class_2170.method_9244("service", StringArgumentType.word())
								.then(class_2170.method_9244("from", StringArgumentType.word())
										.then(class_2170.method_9244("to", StringArgumentType.word())
												.executes(context -> buyTicket(context, ""))
												.then(class_2170.method_9244("seatClass", StringArgumentType.word())
														.executes(context -> buyTicket(context,
																StringArgumentType.getString(context, "seatClass"))))))));
		root.then(class_2170.method_9247("ticket")
				.then(buy)
				.then(class_2170.method_9247("list").executes(TicketCommands::listTickets)));

		root.then(class_2170.method_9247("login")
				.then(class_2170.method_9244("player", StringArgumentType.word())
						.executes(TicketCommands::issueLoginCode)));

		root.then(class_2170.method_9247("balance")
				.then(class_2170.method_9244("player", StringArgumentType.word())
						.executes(TicketCommands::showBalance)
						.then(class_2170.method_9244("amount", IntegerArgumentType.integer(-1000000, 1000000))
								.executes(context -> changeBalance(context,
										IntegerArgumentType.getInteger(context, "amount"))))));

		dispatcher.register(root);
	}

	private static void registerPlayer(final CommandDispatcher<class_2168> dispatcher) {
		dispatcher.register(class_2170.method_9247("ticket")
				.executes(TicketCommands::myTickets)
				.then(class_2170.method_9247("list").executes(TicketCommands::myTickets))
				.then(class_2170.method_9247("login").executes(TicketCommands::loginCode)));
	}

	/* ------------------------------------------------------------------ 玩家命令 */

	private static int loginCode(final CommandContext<class_2168> context) throws CommandSyntaxException {
		final class_3222 player = player(context);
		final TicketingManager manager = requireManager(context);
		final String code = manager.createLoginCode(player.method_7334().getName());
		player.method_7353(class_2561.method_43470("§6§lMTR-12306 网页登录验证码：§e" + code), false);
		player.method_7353(class_2561.method_43470("§7请在购票网页输入玩家 ID §f" + player.method_7334().getName()
				+ " §7与该验证码，§c" + Mtr12306.CONFIG.loginCodeMinutes + " 分钟内有效§7。"), false);
		if (Mtr12306.webServer() != null && Mtr12306.webServer().isRunning()) {
			player.method_7353(class_2561.method_43470("§7购票地址：§b" + Mtr12306.webServer().url()), false);
		}
		return 1;
	}

	private static int myTickets(final CommandContext<class_2168> context) throws CommandSyntaxException {
		final class_3222 player = player(context);
		final TicketingManager manager = Mtr12306.manager();
		if (manager == null) {
			send(context, "§c购票系统尚未就绪");
			return 0;
		}
		final List<Ticket> tickets = manager.ticketsOf(player.method_7334().getName());
		send(context, "§6我的车票（" + tickets.size() + " 张）· 余额 "
				+ FareAccount.balance(manager.server(), player.method_7334().getName()) + " 元");
		for (final Ticket ticket : tickets) {
			send(context, "§b" + ticket.id + " §f" + ticket.serviceNumber + " " + ticket.date + " §7"
					+ manager.data().stationName(ticket.fromStationId) + " " + ticket.fromTime + " → "
					+ manager.data().stationName(ticket.toStationId) + " " + ticket.toTime
					+ " §7" + ticket.seatClassLabel + " " + ticket.seat + " " + ticket.price + "元 状态 " + ticket.state);
		}
		send(context, "§7网页登录：§e/ticket login §7获取验证码");
		return 1;
	}

	/* ------------------------------------------------------------------ 管理命令 */

	private static int help(final CommandContext<class_2168> context) {
		send(context, "§6§lMTR-12306 购票系统§r §7（管理员命令）");
		send(context, "§e/mtr12306 web start|stop|info §7网页服务控制");
		send(context, "§e/mtr12306 station add <名称> [站台1,站台2] | list | remove <id>");
		send(context, "§e/mtr12306 checkpoint add <车站id> <检票口名> [站台…] | list | remove <id>");
		send(context, "§e/mtr12306 service list|remove <车次> §7（车次/坐席/票价在网页后台配置）");
		send(context, "§e/mtr12306 gate bind <检票口id> [ENTRY|EXIT|BOTH|TRANSFER] | unbind | info");
		send(context, "§e/mtr12306 gate simulate <x> <y> <z> <玩家> <in|out> [consume] [apply] §7闸机判定自检（apply=同时驱动闸机状态）");
		send(context, "§e/mtr12306 boarding list | open <车次> <车站id> [分钟] | close <车次> <车站id>");
		send(context, "§e/mtr12306 ticket buy <玩家> <车次> <出发站id> <到达站id> [坐席码]");
		send(context, "§e/mtr12306 ticket list");
		send(context, "§e/mtr12306 balance <玩家> [充值金额] §7查看/调整票价余额（MTR fares）");
		send(context, "§e/mtr12306 login <玩家> §7为其签发网页登录验证码");
		send(context, "§7乘客：§e/ticket §7查看车票，§e/ticket login §7获取网页登录验证码");
		return 1;
	}

	private static int webStart(final CommandContext<class_2168> context) {
		final TicketingManager manager = requireManager(context);
		WebServer webServer = Mtr12306.webServer();
		if (webServer != null && webServer.isRunning()) {
			send(context, "§e网页服务已在运行：§b" + webServer.url());
			return 1;
		}
		webServer = new WebServer(manager);
		webServer.start(Mtr12306.CONFIG.webBind, Mtr12306.CONFIG.webPort);
		send(context, "§a网页服务已启动：§b" + webServer.url() + " §7（后台 " + webServer.url() + "admin）");
		return 1;
	}

	private static int webStop(final CommandContext<class_2168> context) {
		final WebServer webServer = Mtr12306.webServer();
		if (webServer != null) {
			webServer.stop();
			send(context, "§a网页服务已停止");
		} else {
			send(context, "§7网页服务未运行");
		}
		return 1;
	}

	private static int webInfo(final CommandContext<class_2168> context) {
		final WebServer webServer = Mtr12306.webServer();
		send(context, webServer != null && webServer.isRunning()
				? "§a网页购票地址：§b" + webServer.url() + " §7后台：§b" + webServer.url() + "admin"
				: "§7网页服务未运行，使用 §e/mtr12306 web start §7启动");
		return 1;
	}

	private static int addStation(final CommandContext<class_2168> context, final String platforms) {
		final TicketingManager manager = requireManager(context);
		final Station station = manager.addStation(StringArgumentType.getString(context, "name"), "", splitCsv(platforms));
		send(context, "§a已创建车站 §e" + station.id + " " + station.name + " §7站台 " + String.join(",", station.platforms));
		return 1;
	}

	private static int listStations(final CommandContext<class_2168> context) {
		final TicketingManager manager = requireManager(context);
		if (manager.data().stations.isEmpty()) {
			send(context, "§7还没有车站，使用 §e/mtr12306 station add <名称> §7新增，或到网页后台创建");
			return 1;
		}
		for (final Station station : manager.data().stations.values()) {
			int checkpoints = 0;
			for (final Checkpoint checkpoint : manager.data().checkpoints.values()) {
				if (checkpoint.stationId.equals(station.id)) {
					checkpoints++;
				}
			}
			send(context, "§b" + station.id + " §f" + station.name + " §7站台[" + String.join(",", station.platforms)
					+ "] 检票口 " + checkpoints + " 个");
		}
		return 1;
	}

	private static int removeStation(final CommandContext<class_2168> context) {
		requireManager(context).removeStation(StringArgumentType.getString(context, "id"));
		send(context, "§a已删除车站");
		return 1;
	}

	private static int addCheckpoint(final CommandContext<class_2168> context, final String platforms) {
		final TicketingManager manager = requireManager(context);
		final Checkpoint checkpoint = manager.addCheckpoint(StringArgumentType.getString(context, "station"),
				StringArgumentType.getString(context, "name"), splitCsv(platforms));
		send(context, "§a已创建检票口 §e" + checkpoint.id + " " + manager.data().stationName(checkpoint.stationId)
				+ " " + checkpoint.name);
		return 1;
	}

	private static int listCheckpoints(final CommandContext<class_2168> context) {
		final TicketingManager manager = requireManager(context);
		if (manager.data().checkpoints.isEmpty()) {
			send(context, "§7还没有检票口");
			return 1;
		}
		for (final Checkpoint checkpoint : manager.data().checkpoints.values()) {
			send(context, "§b" + checkpoint.id + " §f" + manager.data().stationName(checkpoint.stationId) + " "
					+ checkpoint.name + " §7站台[" + String.join(",", checkpoint.platforms) + "]"
					+ (checkpoint.enabled ? "" : " §c已停用"));
		}
		return 1;
	}

	private static int removeCheckpoint(final CommandContext<class_2168> context) {
		requireManager(context).removeCheckpoint(StringArgumentType.getString(context, "id"));
		send(context, "§a已删除检票口");
		return 1;
	}

	private static int listServices(final CommandContext<class_2168> context) {
		final TicketingManager manager = requireManager(context);
		if (manager.data().services.isEmpty()) {
			send(context, "§7还没有车次，请在网页后台「车次管理」中添加");
			return 1;
		}
		for (final TrainService service : manager.data().services.values()) {
			final List<String> names = new ArrayList<>();
			service.stops.forEach(stop -> names.add(manager.data().stationName(stop.stationId)));
			send(context, "§b" + service.number + " §7[" + service.date + "] " + String.join(" → ", names)
					+ " §7坐席 " + service.effectiveSeatClasses().size() + " 种 定员 " + service.totalSeats());
		}
		return 1;
	}

	private static int removeService(final CommandContext<class_2168> context) {
		requireManager(context).removeService(StringArgumentType.getString(context, "number"));
		send(context, "§a已删除车次");
		return 1;
	}

	private static int bindGate(final CommandContext<class_2168> context) throws CommandSyntaxException {
		return bindGate(context, StringArgumentType.getString(context, "checkpoint"), "ENTRY");
	}

	private static int bindGateWithMode(final CommandContext<class_2168> context) throws CommandSyntaxException {
		return bindGate(context, StringArgumentType.getString(context, "checkpoint"),
				StringArgumentType.getString(context, "mode"));
	}

	private static int unbindGate(final CommandContext<class_2168> context) throws CommandSyntaxException {
		return bindGate(context, "", "ENTRY");
	}

	private static int bindGate(final CommandContext<class_2168> context, final String checkpointId,
			final String mode) throws CommandSyntaxException {
		final class_3222 player = player(context);
		final TicketingManager manager = requireManager(context);
		final class_2338 pos = findGate(player);
		if (pos == null) {
			send(context, "§c请看向闸机方块（或将闸机放在脚下）");
			return 0;
		}
		if (!(player.method_37908().method_8321(pos) instanceof TicketGateBlockEntity gate)) {
			send(context, "§c目标方块不是检票闸机");
			return 0;
		}
		if (!checkpointId.isEmpty() && manager.data().checkpoint(checkpointId) == null) {
			send(context, "§c检票口不存在: " + checkpointId);
			return 0;
		}
		gate.setCheckpoint(checkpointId, mode);
		gate.syncBinding();
		send(context, "§a闸机已设置：检票口 §e" + gate.bindingLabel() + " §a模式 §e" + gate.mode());
		return 1;
	}

	/**
	 * 自检：对指定坐标的闸机按真实判定流程走一遍（默认只读，加 consume 才核销车票）。
	 * 用法：/mtr12306 gate simulate <x> <y> <z> <玩家> <in|out> [consume]
	 */
	/** simulate 命令的 <direction> [consume] [apply] 节点 */
	private static com.mojang.brigadier.builder.RequiredArgumentBuilder<class_2168, String> simulateDirectionNode() {
		final com.mojang.brigadier.builder.RequiredArgumentBuilder<class_2168, String> node = class_2170
				.method_9244("direction", StringArgumentType.word())
				.executes(context -> simulateGate(context, false, false));
		node.then(class_2170.method_9247("apply").executes(context -> simulateGate(context, false, true)));
		node.then(class_2170.method_9247("consume")
				.executes(context -> simulateGate(context, true, false))
				.then(class_2170.method_9247("apply").executes(context -> simulateGate(context, true, true))));
		return node;
	}

	private static int simulateGate(final CommandContext<class_2168> context, final boolean consume,
			final boolean applyEffects) {
		final class_2168 source = context.getSource();
		final net.minecraft.class_3218 world = source.method_9225();
		final class_2338 pos = new class_2338(IntegerArgumentType.getInteger(context, "x"),
				IntegerArgumentType.getInteger(context, "y"), IntegerArgumentType.getInteger(context, "z"));
		if (!(world.method_8321(pos) instanceof TicketGateBlockEntity gate)) {
			send(context, "§c该坐标不是检票闸机");
			return 0;
		}
		final String player = StringArgumentType.getString(context, "player");
		final String direction = StringArgumentType.getString(context, "direction");
		final boolean inbound = !"out".equalsIgnoreCase(direction);
		final net.minecraft.class_2680 state = world.method_8320(pos);
		final TicketGateBlockEntity.Decision decision = gate.decide(world, pos, state, player, inbound, consume);
		send(context, "§6闸机 §f" + pos.method_23854() + " §7模式 §f" + gate.mode() + " §7检票口 §f"
				+ gate.bindingLabel() + " §7方向 §f" + (inbound ? "进站" : "出站") + " §7（"
				+ (consume ? "核销" : "只读") + "）");
		send(context, decision.allowed() ? "§a判定：ALLOW（放行）" : ("§c判定：" + decision.action));
		send(context, "§7说明：" + decision.message);
		for (final String line : decision.detail.split("\n")) {
			if (!line.isBlank()) {
				send(context, "§f  " + line);
			}
		}
		return 1;
	}

	/**
	 * 自检：在闸机位置临时生成一个玩家实体，真实走一遍 handlePlayer（开闸/推回等效果会真的发生），
	 * 结束后丢弃该临时实体。用于在没有客户端接入时验证闸机是否正常工作。
	 */
	private static int mockPass(final CommandContext<class_2168> context) {
		final class_2168 source = context.getSource();
		final net.minecraft.class_3218 world = source.method_9225();
		final class_2338 pos = new class_2338(IntegerArgumentType.getInteger(context, "x"),
				IntegerArgumentType.getInteger(context, "y"), IntegerArgumentType.getInteger(context, "z"));
		if (!(world.method_8321(pos) instanceof TicketGateBlockEntity gate)) {
			send(context, "§c该坐标不是检票闸机");
			return 0;
		}
		final String name = StringArgumentType.getString(context, "player");
		final boolean inbound = !"out".equalsIgnoreCase(StringArgumentType.getString(context, "direction"));
		final net.minecraft.class_2680 state = world.method_8320(pos);
		final net.minecraft.class_2350 facing = state.method_11654(TicketGateBlock.FACING);
		final net.minecraft.class_243 center = net.minecraft.class_243.method_24953(pos);
		final double sign = inbound ? -1.0D : 1.0D;
		final java.util.UUID uuid = java.util.UUID.nameUUIDFromBytes(name.getBytes(java.nio.charset.StandardCharsets.UTF_8));
		net.minecraft.class_3222 fake = null;
		try {
			fake = new net.minecraft.class_3222(source.method_9211(), world,
					new com.mojang.authlib.GameProfile(uuid, name));
			fake.method_23327(center.field_1352 + facing.method_10148() * 0.45D * sign, pos.method_10264(),
					center.field_1350 + facing.method_10165() * 0.45D * sign);
			final net.minecraft.class_243 before = new net.minecraft.class_243(fake.method_23317(), fake.method_23318(), fake.method_23321());
			gate.tryPass(world, pos, state, fake);
			final net.minecraft.class_243 after = new net.minecraft.class_243(fake.method_23317(), fake.method_23318(), fake.method_23321());
			final net.minecraft.class_2680 now = world.method_8320(pos);
			final String gateState = String.valueOf(now.method_11654(TicketGateBlock.OPEN));
			send(context, "§6临时玩家 §f" + name + " §7于 §f" + pos.method_23854() + " §7（" + (inbound ? "进站" : "出站")
					+ "方向，模式 " + gate.mode() + "）");
			send(context, "§7闸机状态：§f" + gateState + " §7｜位移：§f" + String.format("%.2f", before.method_1022(after))
					+ " §7格（>0 表示被推回）");
			send(context, "§7判定：" + ("open".equals(gateState) ? "§a放行（已开闸）"
					: ("pending".equals(gateState) ? "§c拒绝（红箭 + 推回）" : "§e未触发（可能是开门状态或冷却）")));
		} catch (Throwable throwable) {
			send(context, "§c自检失败：" + throwable);
		} finally {
			if (fake != null) {
				fake.method_31472();
			}
		}
		return 1;
	}

	private static int gateInfo(final CommandContext<class_2168> context) throws CommandSyntaxException {
		final class_3222 player = player(context);
		final class_2338 pos = findGate(player);
		if (pos == null) {
			send(context, "§c请看向闸机方块（或将闸机放在脚下）");
			return 0;
		}
		if (player.method_37908().method_8321(pos) instanceof TicketGateBlockEntity gate) {
			send(context, "§a闸机 §7" + pos.method_23854() + " §a检票口：§e" + gate.bindingLabel()
					+ " §a模式：§e" + gate.mode() + " §7（ENRTY=进站检票 EXIT=出站放行 BOTH=双向）");
		}
		return 1;
	}

	private static int listBoarding(final CommandContext<class_2168> context) {
		final TicketingManager manager = requireManager(context);
		final List<TicketingManager.BoardingEntry> entries = manager.boardingEntries(TicketingManager.today());
		if (entries.isEmpty()) {
			send(context, "§7今日没有车次发车计划");
			return 1;
		}
		for (final TicketingManager.BoardingEntry entry : entries) {
			send(context, (entry.openNow ? "§a[检票中] " : "§7[未开始] ") + "§f" + entry.service.number + " §7"
					+ manager.data().stationName(entry.stop.stationId) + " " + entry.stop.depart
					+ " 站台" + entry.stop.platform + " 检票口"
					+ (entry.checkpoint == null ? "未设置" : entry.checkpoint.name));
		}
		return 1;
	}

	private static int openBoarding(final CommandContext<class_2168> context, final int minutes) {
		final TicketingManager manager = requireManager(context);
		manager.openBoarding(StringArgumentType.getString(context, "service"),
				StringArgumentType.getString(context, "station"), minutes);
		send(context, "§a已手动开始检票，持续 " + minutes + " 分钟");
		return 1;
	}

	private static int closeBoarding(final CommandContext<class_2168> context) {
		requireManager(context).closeBoarding(StringArgumentType.getString(context, "service"),
				StringArgumentType.getString(context, "station"));
		send(context, "§a已强制停止检票 " + Mtr12306.CONFIG.manualCloseMinutes + " 分钟（覆盖自动检票窗口）");
		return 1;
	}

	private static int buyTicket(final CommandContext<class_2168> context, final String seatClass) {
		final TicketingManager manager = requireManager(context);
		final TrainService service = manager.data().service(StringArgumentType.getString(context, "service"));
		if (service == null) {
			send(context, "§c车次不存在");
			return 0;
		}
		final String fromId = StringArgumentType.getString(context, "from");
		final ServiceStop fromStop = service.stopAt(fromId);
		if (fromStop == null) {
			send(context, "§c该车次不经过出发站");
			return 0;
		}
		final LocalDate serviceDate = TicketingManager.today().minusDays(fromStop.dayOffset);
		final Ticket ticket = manager.purchase(
				StringArgumentType.getString(context, "player"),
				service.number,
				serviceDate.toString(),
				fromId,
				StringArgumentType.getString(context, "to"),
				seatClass,
				0,
				"");
		send(context, "§a出票成功：§e" + ticket.id + " §7" + manager.data().stationName(ticket.fromStationId)
				+ " → " + manager.data().stationName(ticket.toStationId) + " " + ticket.fromTime
				+ " §7" + ticket.seatClassLabel + " " + ticket.seat + " §e" + ticket.price + " 元");
		return 1;
	}

	private static int listTickets(final CommandContext<class_2168> context) {
		final TicketingManager manager = requireManager(context);
		send(context, "§a已售车票 " + manager.data().tickets.size() + " 张");
		manager.data().tickets.values().stream().limit(20)
				.forEach(ticket -> send(context, "§7" + ticket.id + " §f" + ticket.playerName + " §7"
						+ ticket.serviceNumber + " " + manager.data().stationName(ticket.fromStationId) + "→"
						+ manager.data().stationName(ticket.toStationId) + " " + ticket.seatClassLabel + " "
						+ ticket.seat + " " + ticket.state));
		return 1;
	}

	/** 管理员/控制台为指定玩家签发网页登录验证码 */
	private static int issueLoginCode(final CommandContext<class_2168> context) {
		final String player = StringArgumentType.getString(context, "player");
		final String code = requireManager(context).createLoginCode(player);
		send(context, "§a已为 " + player + " 生成网页登录验证码：§e" + code + " §7（"
				+ Mtr12306.CONFIG.loginCodeMinutes + " 分钟内有效，5 次输错作废）");
		return 1;
	}

	private static int showBalance(final CommandContext<class_2168> context) {
		final TicketingManager manager = requireManager(context);
		final String player = StringArgumentType.getString(context, "player");
		send(context, "§a" + player + " 的票价余额：§e" + FareAccount.balance(manager.server(), player)
				+ " 元 §7（计分板 " + FareAccount.objectiveName() + "）");
		return 1;
	}

	private static int changeBalance(final CommandContext<class_2168> context, final int amount) {
		final TicketingManager manager = requireManager(context);
		final String player = StringArgumentType.getString(context, "player");
		if (amount >= 0) {
			FareAccount.deposit(manager.server(), player, amount);
		} else {
			FareAccount.withdraw(manager.server(), player, -amount);
		}
		send(context, "§a已更新余额：" + player + " → §e" + FareAccount.balance(manager.server(), player) + " 元");
		return 1;
	}

	/* ------------------------------------------------------------------ 工具 */

	private static List<String> splitCsv(final String text) {
		final List<String> list = new ArrayList<>();
		if (text == null || text.isBlank()) {
			return list;
		}
		for (final String part : text.split("[,，]")) {
			if (!part.isBlank()) {
				list.add(part.trim());
			}
		}
		return list;
	}

	private static TicketingManager requireManager(final CommandContext<class_2168> context) {
		final TicketingManager manager = Mtr12306.manager();
		if (manager == null) {
			throw new TicketingException("购票系统尚未就绪");
		}
		return manager;
	}

	private static final SimpleCommandExceptionType PLAYER_ONLY =
			new SimpleCommandExceptionType(class_2561.method_43470("该命令只能由玩家执行"));

	private static class_3222 player(final CommandContext<class_2168> context)
			throws CommandSyntaxException {
		final class_3222 player = context.getSource().method_44023();
		if (player == null) {
			throw PLAYER_ONLY.create();
		}
		return player;
	}

	private static void send(final CommandContext<class_2168> context, final String message) {
		context.getSource().method_9226(() -> class_2561.method_43470(message), false);
	}

	private static class_2338 findGate(final class_3222 player) {
		final class_239 hit = player.method_5745(6.0, 0.0F, false);
		if (hit instanceof class_3965 blockHit
				&& player.method_37908().method_8320(blockHit.method_17777()).method_26204() == ModBlocks.TICKET_GATE) {
			return blockHit.method_17777();
		}
		for (final class_2338 candidate : new class_2338[]{player.method_24515(), player.method_24515().method_10084()}) {
			if (player.method_37908().method_8320(candidate).method_26204() == ModBlocks.TICKET_GATE) {
				return candidate;
			}
		}
		return null;
	}
}
