package com.mtr12306.block;

import net.minecraft.class_1937;
import net.minecraft.class_2338;

public final class GateHelper {
	private GateHelper() {
	}

	public static String dimension(final class_1937 world) {
		return world.method_27983().method_29177().toString();
	}

	public static String key(final class_1937 world, final class_2338 pos) {
		return dimension(world) + "@" + pos.method_10263() + "," + pos.method_10264() + "," + pos.method_10260();
	}
}
