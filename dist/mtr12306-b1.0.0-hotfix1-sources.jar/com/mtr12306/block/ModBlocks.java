package com.mtr12306.block;

import com.mtr12306.Mtr12306;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_2591;
import net.minecraft.class_7923;

public final class ModBlocks {
	public static final class_2248 TICKET_GATE = new TicketGateBlock(
			FabricBlockSettings.method_9637().method_9629(2.0F, 6.0F).method_9626(class_2498.field_11533).method_22488().method_29292()
	);

	public static final class_2591<TicketGateBlockEntity> TICKET_GATE_ENTITY = FabricBlockEntityTypeBuilder
			.create(TicketGateBlockEntity::new, TICKET_GATE)
			.build();

	private ModBlocks() {
	}

	public static void register() {
		class_2378.method_10230(class_7923.field_41175, Mtr12306.id("ticket_gate"), TICKET_GATE);
		class_2378.method_10230(class_7923.field_41181, Mtr12306.id("ticket_gate"), TICKET_GATE_ENTITY);
	}
}
