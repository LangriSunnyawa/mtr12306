package com.mtr12306.block;

import com.mtr12306.Mtr12306;
import com.mtr12306.net.ModNetworking;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2464;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2753;
import net.minecraft.class_2754;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3542;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_5819;
import org.jetbrains.annotations.Nullable;

/**
 * 检票闸机（使用 MTR 闸机的模型与通行方式）。
 * 模型几何来自 MTR 的 ticket_barrier（MIT），贴图做了重新配色。
 *
 * <p>状态机与 MTR 一致：closed / pending / open；玩家走到闸机所在格触发检票，
 * 通过时闸机指示灯变绿（箭头向上），否则显示红色箭头并把玩家推回去。</p>
 */
public class TicketGateBlock extends class_2237 {
	public static final class_2753 FACING = class_2383.field_11177;
	/** 闸机状态：closed=待机，pending=拒绝，open=已放行（与 MTR 闸机一致） */
	public enum GateState implements class_3542 {
		CLOSED("closed"), PENDING("pending"), OPEN("open");

		private final String id;

		GateState(final String id) {
			this.id = id;
		}

		@Override
		public String method_15434() {
			return id;
		}
	}

	/** 视觉类型：entrance=进站（橙色底座），exit=出站（绿色底座），与 MTR 的进/出闸机对应 */
	public enum GateKind implements class_3542 {
		ENTRANCE("entrance"), EXIT("exit");

		private final String id;

		GateKind(final String id) {
			this.id = id;
		}

		@Override
		public String method_15434() {
			return id;
		}
	}

	public static final class_2754<GateState> OPEN = class_2754.method_11850("open", GateState.class);
	public static final class_2754<GateKind> KIND = class_2754.method_11850("kind", GateKind.class);

	/** 机柜碰撞箱（按朝向取不同半边，与模型一致） */
	private static final class_265 SHAPE_NORTH = class_2248.method_9541(12.0, 0.0, 0.0, 16.0, 15.0, 16.0);
	private static final class_265 SHAPE_EAST = class_2248.method_9541(0.0, 0.0, 12.0, 16.0, 15.0, 16.0);
	private static final class_265 SHAPE_SOUTH = class_2248.method_9541(0.0, 0.0, 0.0, 4.0, 15.0, 16.0);
	private static final class_265 SHAPE_WEST = class_2248.method_9541(0.0, 0.0, 0.0, 16.0, 15.0, 4.0);
	/** 轮廓用整格，方便右键点到闸机 */
	private static final class_265 OUTLINE = class_2248.method_9541(0.0, 0.0, 0.0, 16.0, 16.0, 16.0);

	public TicketGateBlock(final class_2251 settings) {
		super(settings);
		method_9590(method_9564().method_11657(FACING, class_2350.field_11043).method_11657(OPEN, GateState.CLOSED)
				.method_11657(KIND, GateKind.ENTRANCE));
	}

	@Override
	protected void method_9515(final class_2689.class_2690<class_2248, class_2680> builder) {
		builder.method_11667(FACING, OPEN, KIND);
	}

	@Override
	public class_2680 method_9605(final class_1750 ctx) {
		return method_9564().method_11657(FACING, ctx.method_8042());
	}

	@Override
	public class_2464 method_9604(final class_2680 state) {
		return class_2464.field_11458;
	}

	@Override
	public class_265 method_9530(final class_2680 state, final class_1922 world, final class_2338 pos,
			final class_3726 context) {
		return OUTLINE;
	}

	@Override
	public class_265 method_9549(final class_2680 state, final class_1922 world, final class_2338 pos,
			final class_3726 context) {
		return switch (state.method_11654(FACING)) {
			case field_11034 -> SHAPE_EAST;
			case field_11035 -> SHAPE_SOUTH;
			case field_11039 -> SHAPE_WEST;
			default -> SHAPE_NORTH;
		};
	}

	@Nullable
	@Override
	public class_2586 method_10123(final class_2338 pos, final class_2680 state) {
		return new TicketGateBlockEntity(pos, state);
	}

	@Nullable
	@Override
	public <T extends class_2586> net.minecraft.class_5558<T> method_31645(final class_1937 world,
			final class_2680 state, final net.minecraft.class_2591<T> type) {
		if (world.method_8608()) {
			return null;
		}
		return (tickWorld, tickPos, tickState, blockEntity) -> {
			if (blockEntity instanceof TicketGateBlockEntity gate) {
				gate.serverTick(tickWorld, tickPos, tickState);
			}
		};
	}


	/** 玩家踩进闸机所在方块时触发检票（MTR 的闸机也是这么做的） */
	@Override
	public void method_9548(final class_2680 state, final class_1937 world, final class_2338 pos, final class_1297 entity) {
		if (world.method_8608() || !(entity instanceof class_3222 player)) {
			return;
		}
		if (world.method_8321(pos) instanceof TicketGateBlockEntity gate) {
			gate.handlePlayer((class_3218) world, pos, state, player);
		}
	}

	@Override
	public void method_9588(final class_2680 state, final class_3218 world, final class_2338 pos, final class_5819 random) {
		if (state.method_11654(OPEN) != GateState.CLOSED) {
			world.method_8652(pos, state.method_11657(OPEN, GateState.CLOSED), class_2248.field_31028);
		}
	}

	@Override
	public void method_9567(final class_1937 world, final class_2338 pos, final class_2680 state, @Nullable final class_1309 placer,
			final class_1799 itemStack) {
		super.method_9567(world, pos, state, placer, itemStack);
		if (world.method_8608() || !(world.method_8321(pos) instanceof TicketGateBlockEntity gate)) {
			return;
		}
		// 相邻闸机自动继承检票口与模式，方便成排布置
		for (final class_2350 direction : class_2350.class_2353.field_11062) {
			final class_2586 neighbour = world.method_8321(pos.method_10093(direction));
			if (neighbour instanceof TicketGateBlockEntity other && !other.checkpointId().isEmpty()) {
				gate.setCheckpoint(other.checkpointId(), other.mode());
				break;
			}
		}
		gate.syncBinding();
		if (Mtr12306.manager() != null) {
			Mtr12306.manager().bindGate(GateHelper.dimension(world), pos.method_10263(), pos.method_10264(), pos.method_10260(),
					gate.checkpointId(), gate.mode());
		}
	}

	@Override
	public void method_9536(final class_2680 state, final class_1937 world, final class_2338 pos, final class_2680 newState,
			final boolean moved) {
		if (!world.method_8608() && !state.method_27852(newState.method_26204()) && Mtr12306.manager() != null) {
			Mtr12306.manager().removeGate(GateHelper.key(world, pos));
		}
		super.method_9536(state, world, pos, newState, moved);
	}

	@Override
	public class_1269 method_9534(final class_2680 state, final class_1937 world, final class_2338 pos, final class_1657 player,
			final class_1268 hand, final class_3965 hit) {
		if (world.method_8608()) {
			return class_1269.field_5812;
		}
		if (!(player instanceof class_3222 serverPlayer)) {
			return class_1269.field_5811;
		}
		if (!(world.method_8321(pos) instanceof TicketGateBlockEntity gate)) {
			return class_1269.field_5811;
		}
		gate.syncBinding();
		serverPlayer.method_7353(class_2561.method_43470("§e此闸机：§f" + gate.checkpointName() + " §7模式 §f" + gate.mode()), true);
		if (serverPlayer.method_5687(2)) {
			serverPlayer.method_7353(class_2561.method_43470("§7拿 §f闸机配置面板 §7右键可修改配置"), false);
		}
		return class_1269.field_5812;
	}
}
