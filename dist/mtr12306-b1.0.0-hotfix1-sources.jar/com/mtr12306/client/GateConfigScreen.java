package com.mtr12306.client;

import com.mtr12306.net.ModNetworking;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import java.util.ArrayList;
import java.util.List;

/**
 * 闸机配置界面：选择该闸机所属检票口（仅限闸机所在 MTR 车站）与通行模式。
 */
public class GateConfigScreen extends class_437 {
	private static final int PER_PAGE = 5;
	private static final String[] MODES = {"ENTRY", "EXIT", "BOTH", "TRANSFER"};

	private final class_2338 pos;
	private final String stationName;
	private final List<String[]> options;
	private String selected;
	private String mode;
	private int page = 0;

	public GateConfigScreen(final class_2338 pos, final String currentCheckpointId, final String currentMode,
			final String stationName, final List<String[]> options) {
		super(class_2561.method_43470("闸机配置"));
		this.pos = pos;
		this.selected = currentCheckpointId == null ? "" : currentCheckpointId;
		this.mode = currentMode == null || currentMode.isBlank() ? "ENTRY" : currentMode;
		this.stationName = stationName == null ? "" : stationName;
		this.options = options == null ? new ArrayList<>() : options;
	}

	private static String modeText(final String mode) {
		return switch (mode) {
			case "EXIT" -> "出站放行";
			case "BOTH" -> "双向检票";
			case "TRANSFER" -> "换乘闸机";
			default -> "进站检票";
		};
	}

	@Override
	protected void method_25426() {
		final int centerX = field_22789 / 2;
		int y = 56;

		method_37063(class_4185.method_46430(class_2561.method_43470("通行模式：" + modeText(mode)), button -> {
			int index = 0;
			for (int i = 0; i < MODES.length; i++) {
				if (MODES[i].equals(mode)) {
					index = i;
				}
			}
			mode = MODES[(index + 1) % MODES.length];
			button.method_25355(class_2561.method_43470("通行模式：" + modeText(mode)));
		}).method_46434(centerX - 110, y, 220, 20).method_46431());
		y += 26;

		final int pages = Math.max(1, (options.size() + PER_PAGE - 1) / PER_PAGE);
		page = Math.min(page, pages - 1);
		final int start = page * PER_PAGE;
		for (int i = 0; i < PER_PAGE && start + i < options.size(); i++) {
			final String[] option = options.get(start + i);
			final String id = option[0];
			final String label = option[1];
			final boolean isSelected = id.equals(selected);
			method_37063(class_4185.method_46430(class_2561.method_43470((isSelected ? "§a✔ " : "") + label), button -> {
				selected = id;
				method_41843();
			}).method_46434(centerX - 150, y, 300, 20).method_46431());
			y += 23;
		}

		if (pages > 1) {
			final int pageY = field_22790 - 56;
			method_37063(class_4185.method_46430(class_2561.method_43470("◀"), button -> {
				page = (page - 1 + pages) % pages;
				method_41843();
			}).method_46434(centerX - 152, pageY, 40, 20).method_46431());
			method_37063(class_4185.method_46430(class_2561.method_43470("第 " + (page + 1) + "/" + pages + " 页"), button -> {
			}).method_46434(centerX - 108, pageY, 216, 20).method_46431());
			method_37063(class_4185.method_46430(class_2561.method_43470("▶"), button -> {
				page = (page + 1) % pages;
				method_41843();
			}).method_46434(centerX + 112, pageY, 40, 20).method_46431());
		}

		method_37063(class_4185.method_46430(class_2561.method_43470("§a保存"), button -> save())
				.method_46434(centerX - 152, field_22790 - 28, 148, 20).method_46431());
		method_37063(class_4185.method_46430(class_2561.method_43470("§c取消"), button -> method_25419())
				.method_46434(centerX + 4, field_22790 - 28, 148, 20).method_46431());
	}

	private void save() {
		final class_2540 buf = PacketByteBufs.create();
		buf.method_10807(pos);
		buf.method_10814(selected);
		buf.method_10814(mode);
		ClientPlayNetworking.send(ModNetworking.BIND_GATE, buf);
		method_25419();
	}

	@Override
	public void method_25394(final class_332 context, final int mouseX, final int mouseY, final float delta) {
		method_25420(context);
		context.method_27534(field_22793, field_22785, field_22789 / 2, 16, 0xFFFFFF);
		context.method_27534(field_22793,
				class_2561.method_43470("§7闸机坐标 " + pos.method_10263() + ", " + pos.method_10264() + ", " + pos.method_10260()), field_22789 / 2, 30, 0xAAAAAA);
		if (stationName.isEmpty()) {
			context.method_27534(field_22793,
					class_2561.method_43470("§c此闸机不在任何 MTR 车站范围内，无法选择检票口"), field_22789 / 2, 44, 0xFF5555);
		} else {
			context.method_27534(field_22793,
					class_2561.method_43470("§b所在车站：" + stationName), field_22789 / 2, 44, 0x55FFFF);
		}
		if (options.isEmpty()) {
			context.method_27534(field_22793,
					class_2561.method_43470(stationName.isEmpty()
							? "§7请先把闸机放到 MTR 车站范围内"
							: "§7该车站还没有检票口（请在网页后台为同名车站创建检票口）"),
					field_22789 / 2, 80, 0xAAAAAA);
		}
		context.method_27534(field_22793,
				class_2561.method_43470("§7当前选择：" + (selected.isEmpty() ? "未绑定" : selected)), field_22789 / 2, field_22790 - 44, 0xFFFFFF);
		super.method_25394(context, mouseX, mouseY, delta);
	}

	@Override
	public boolean method_25421() {
		return false;
	}
}
