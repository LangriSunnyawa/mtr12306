package com.mtr12306.client;

import com.mtr12306.net.ModNetworking;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2338;
import java.util.ArrayList;
import java.util.List;

public class Mtr12306Client implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		ClientPlayNetworking.registerGlobalReceiver(ModNetworking.OPEN_GATE_CONFIG, (client, handler, buf, responseSender) -> {
			final class_2338 pos = buf.method_10811();
			final String currentCheckpointId = buf.method_10800(32767);
			final String currentMode = buf.method_10800(16);
			final String stationName = buf.method_10800(32767);
			final int count = buf.readInt();
			final List<String[]> options = new ArrayList<>();
			for (int i = 0; i < count; i++) {
				final String id = buf.method_10800(32767);
				final String label = buf.method_10800(32767);
				options.add(new String[]{id, label});
			}
			client.execute(() -> client.method_1507(new GateConfigScreen(pos, currentCheckpointId, currentMode, stationName, options)));
		});
	}
}
