package com.mtr12306.fares;

import com.mtr12306.Mtr12306;
import net.minecraft.class_2561;
import net.minecraft.class_266;
import net.minecraft.class_267;
import net.minecraft.class_269;
import net.minecraft.class_274;
import net.minecraft.server.MinecraftServer;

/**
 * 与 MTR 自带的票价钱包（fares scoreboard）对接。
 * MTR 把余额存在名为 mtr_balance 的计分板项目里（标题 Balance），
 * 这里读写同一个项目，因此与 MTR 的售票机、闸机共用余额。
 */
public final class FareAccount {
	private static final String FALLBACK_OBJECTIVE = "mtr_balance";
	private static final String FALLBACK_TITLE = "Balance";
	private static String objectiveName;
	private static String objectiveTitle;

	private FareAccount() {
	}

	/** 计分板项目名，优先使用配置，其次取 MTR 的常量，最后回退到 mtr_balance */
	public static synchronized String objectiveName() {
		if (objectiveName != null) {
			return objectiveName;
		}
		final String configured = Mtr12306.CONFIG == null ? "" : Mtr12306.CONFIG.fareObjective;
		if (configured != null && !configured.isBlank()) {
			objectiveName = configured.trim();
			return objectiveName;
		}
		objectiveName = readMtrConstant("BALANCE_OBJECTIVE", FALLBACK_OBJECTIVE);
		return objectiveName;
	}

	public static synchronized String objectiveTitle() {
		if (objectiveTitle != null) {
			return objectiveTitle;
		}
		objectiveTitle = readMtrConstant("BALANCE_OBJECTIVE_TITLE", FALLBACK_TITLE);
		return objectiveTitle;
	}

	private static String readMtrConstant(final String fieldName, final String fallback) {
		try {
			final Class<?> clazz = Class.forName("org.mtr.mod.data.TicketSystem");
			final Object value = clazz.getField(fieldName).get(null);
			if (value instanceof String string && !string.isBlank()) {
				return string;
			}
		} catch (Throwable ignored) {
		}
		return fallback;
	}

	public static void invalidateCache() {
		objectiveName = null;
		objectiveTitle = null;
	}

	private static class_266 objective(final MinecraftServer server, final boolean create) {
		if (server == null) {
			return null;
		}
		final class_269 scoreboard = server.method_3845();
		class_266 objective = scoreboard.method_1170(objectiveName());
		if (objective == null && create) {
			objective = scoreboard.method_1168(objectiveName(), class_274.field_1468,
					class_2561.method_43470(objectiveTitle()), class_274.class_275.field_1472);
		}
		return objective;
	}

	/** 读取余额；计分板项目不存在时返回 0 */
	public static int balance(final MinecraftServer server, final String playerName) {
		final class_266 objective = objective(server, false);
		if (objective == null || playerName == null || playerName.isBlank()) {
			return 0;
		}
		final class_267 score = server.method_3845().method_1180(playerName, objective);
		return score == null ? 0 : score.method_1126();
	}

	/** 写入余额（用于扣款与退款） */
	public static void setBalance(final MinecraftServer server, final String playerName, final int value) {
		final class_266 objective = objective(server, true);
		if (objective == null || playerName == null || playerName.isBlank()) {
			return;
		}
		final class_267 score = server.method_3845().method_1180(playerName, objective);
		score.method_1128(Math.max(0, value));
	}

	/** 尝试扣款，余额不足返回 false */
	public static boolean withdraw(final MinecraftServer server, final String playerName, final int amount) {
		if (amount <= 0) {
			return true;
		}
		final int current = balance(server, playerName);
		if (current < amount) {
			return false;
		}
		setBalance(server, playerName, current - amount);
		return true;
	}

	public static void deposit(final MinecraftServer server, final String playerName, final int amount) {
		if (amount <= 0) {
			return;
		}
		setBalance(server, playerName, balance(server, playerName) + amount);
	}
}
