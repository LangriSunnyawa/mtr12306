package com.mtr12306.item;

import com.mtr12306.block.TicketGateBlockEntity;
import com.mtr12306.net.ModNetworking;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

/**
 * 配置面板：管理员（OP）拿它右键闸机即可唤出闸机配置菜单。
 */
public class ConfigToolItem extends class_1792 {
	public ConfigToolItem(final class_1793 settings) {
		super(settings);
	}

	@Override
	public class_1269 method_7884(final class_1838 context) {
		final class_1937 world = context.method_8045();
		final class_1657 player = context.method_8036();
		final class_2338 pos = context.method_8037();
		if (world.method_8608()) {
			return class_1269.field_5812;
		}
		if (!(player instanceof class_3222 serverPlayer)) {
			return class_1269.field_5811;
		}
		if (!serverPlayer.method_5687(2)) {
			serverPlayer.method_7353(class_2561.method_43470("§c配置闸机需要 OP（管理员）权限"), true);
			return class_1269.field_5814;
		}
		if (world.method_8321(pos) instanceof TicketGateBlockEntity gate) {
			ModNetworking.openGateConfig(serverPlayer, gate);
			return class_1269.field_5812;
		}
		serverPlayer.method_7353(class_2561.method_43470("§c请对着检票闸机使用配置面板"), true);
		return class_1269.field_5811;
	}

	@Override
	public class_1271<net.minecraft.class_1799> method_7836(final class_1937 world, final class_1657 user,
			final class_1268 hand) {
		if (!world.method_8608() && user instanceof class_3222 serverPlayer) {
			serverPlayer.method_7353(class_2561.method_43470("§7用法：拿着配置面板 §f右键闸机§7 打开配置菜单（需要 OP 权限）"), false);
			serverPlayer.method_7353(class_2561.method_43470("§7可设置：所属检票口（仅限闸机所在 MTR 车站）与通行模式"), false);
		}
		return super.method_7836(world, user, hand);
	}
}
