package com.mtr12306.item;

import com.mtr12306.Mtr12306;
import com.mtr12306.block.ModBlocks;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_7923;

/**
 * 物品注册：四种通行模式的闸机 + 配置面板，并放进独立的创造模式分类。
 */
public final class ModItems {
	public static final class_1792 GATE_ENTRY = new GateItem(ModBlocks.TICKET_GATE, new class_1792.class_1793(), "ENTRY");
	public static final class_1792 GATE_EXIT = new GateItem(ModBlocks.TICKET_GATE, new class_1792.class_1793(), "EXIT");
	public static final class_1792 GATE_BOTH = new GateItem(ModBlocks.TICKET_GATE, new class_1792.class_1793(), "BOTH");
	public static final class_1792 GATE_TRANSFER = new GateItem(ModBlocks.TICKET_GATE, new class_1792.class_1793(), "TRANSFER");
	public static final class_1792 CONFIG_TOOL = new ConfigToolItem(new class_1792.class_1793().method_7889(1));

	private static final class_1761 GROUP = FabricItemGroup.builder()
			.method_47321(class_2561.method_43471("itemGroup.mtr12306.gates"))
			.method_47320(() -> new class_1799(GATE_ENTRY))
			.method_47317((context, entries) -> {
				entries.method_45421(GATE_ENTRY);
				entries.method_45421(GATE_EXIT);
				entries.method_45421(GATE_BOTH);
				entries.method_45421(GATE_TRANSFER);
				entries.method_45421(CONFIG_TOOL);
			})
			.method_47324();

	private ModItems() {
	}

	public static void register() {
		register("ticket_gate_entry", GATE_ENTRY);
		register("ticket_gate_exit", GATE_EXIT);
		register("ticket_gate_both", GATE_BOTH);
		register("ticket_gate_transfer", GATE_TRANSFER);
		register("config_tool", CONFIG_TOOL);
		class_2378.method_10230(class_7923.field_44687, Mtr12306.id("gates"), GROUP);
	}

	private static void register(final String id, final class_1792 item) {
		class_2378.method_10230(class_7923.field_41178, Mtr12306.id(id), item);
	}
}
