package com.mtr12306.block;

import com.mtr12306.Mtr12306;
import com.mtr12306.TicketingManager;
import com.mtr12306.data.Checkpoint;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5903;
import net.minecraft.class_5904;
import net.minecraft.class_5905;

/**
 * 闸机方块实体：保存所属检票口与通行模式，并处理玩家经过时的检票逻辑。
 * 闸机正面（FACING 方向）为站台侧，玩家从背面走向正面即为进站。
 *
 * <p>模式：
 * ENTRY=进站检票，EXIT=出站放行（记录出闸），BOTH=双向（进站查票/出站查今日已检票），
 * TRANSFER=换乘（一次性完成上一段出闸 + 接续车次检票）。</p>
 */
public class TicketGateBlockEntity extends class_2586 {
	/** 放行后保持开门的时间（tick），与 MTR 的 40 tick 一致 */
	private static final int OPEN_TICKS = 40;
	/** 拒绝时红箭头显示时间（tick） */
	private static final int DENY_TICKS = 30;

	private String checkpointId = "";
	private String mode = "ENTRY";

	private final Map<UUID, Long> allowedUntil = new HashMap<>();
	private final Map<UUID, Long> deniedUntil = new HashMap<>();
	private final Map<UUID, Long> messageCooldown = new HashMap<>();

	public TicketGateBlockEntity(final class_2338 pos, final class_2680 state) {
		super(ModBlocks.TICKET_GATE_ENTITY, pos, state);
	}

	/* ------------------------------------------------------------------ 属性 */

	public String checkpointId() {
		return checkpointId;
	}

	public String mode() {
		return mode;
	}

	public void setCheckpoint(final String checkpointId, final String mode) {
		this.checkpointId = checkpointId == null ? "" : checkpointId;
		this.mode = mode == null || mode.isBlank() ? "ENTRY" : mode.toUpperCase();
		method_5431();
		applyKind();
	}

	/** 出站/换乘闸机用绿色底座模型，进站/双向用橙色底座模型 */
	private void applyKind() {
		if (field_11863 == null || field_11863.method_8608()) {
			return;
		}
		final class_2680 state = field_11863.method_8320(field_11867);
		if (!state.method_28498(TicketGateBlock.KIND)) {
			return;
		}
		final boolean exitLike = "EXIT".equals(mode) || "TRANSFER".equals(mode);
		final TicketGateBlock.GateKind kind = exitLike
				? TicketGateBlock.GateKind.EXIT : TicketGateBlock.GateKind.ENTRANCE;
		if (state.method_11654(TicketGateBlock.KIND) != kind) {
			field_11863.method_8652(field_11867, state.method_11657(TicketGateBlock.KIND, kind), 3);
		}
	}

	public String checkpointName() {
		final TicketingManager manager = Mtr12306.manager();
		if (manager == null || checkpointId.isEmpty()) {
			return "未绑定";
		}
		final Checkpoint checkpoint = manager.data().checkpoint(checkpointId);
		if (checkpoint == null) {
			return "未绑定";
		}
		return manager.data().stationName(checkpoint.stationId) + " " + checkpoint.name;
	}

	/** 把绑定关系同步到购票系统数据（供网页后台查看） */
	public void syncBinding() {
		if (field_11863 == null) {
			return;
		}
		final TicketingManager manager = Mtr12306.manager();
		if (manager == null) {
			TicketingManager.queueGateRegistration(GateHelper.dimension(field_11863), field_11867.method_10263(), field_11867.method_10264(), field_11867.method_10260(),
					checkpointId, mode);
			return;
		}
		manager.bindGateIfAbsent(GateHelper.dimension(field_11863), field_11867.method_10263(), field_11867.method_10264(), field_11867.method_10260(), checkpointId, mode);
	}

	@Override
	public void method_31662(final class_1937 world) {
		super.method_31662(world);
		// 区块加载（含旧存档、结构生成、/setblock）时把闸机补登记到购票系统
		if (world != null && !world.method_8608()) {
			syncBinding();
		}
	}

	@Override
	public void method_11007(final class_2487 nbt) {
		super.method_11007(nbt);
		nbt.method_10582("checkpointId", checkpointId);
		nbt.method_10582("mode", mode);
	}

	@Override
	public void method_11014(final class_2487 nbt) {
		super.method_11014(nbt);
		checkpointId = nbt.method_10558("checkpointId");
		mode = nbt.method_10545("mode") ? nbt.method_10558("mode") : "ENTRY";
	}

	@Override
	public class_2487 method_16887() {
		return method_38244();
	}

	/* ------------------------------------------------------------------ 检票 */

	public void handlePlayer(final class_3218 world, final class_2338 pos, final class_2680 state,
			final class_3222 player) {
		// 与 MTR 一致：只在待机状态触发，开门期间不重复检票
		if (state.method_11654(TicketGateBlock.OPEN) != TicketGateBlock.GateState.CLOSED || player.method_7325()
				|| player.method_7337()) {
			return;
		}
		final long now = System.currentTimeMillis();
		if (allowedUntil.size() > 64) {
			allowedUntil.values().removeIf(time -> time < now);
			deniedUntil.values().removeIf(time -> time < now);
			messageCooldown.values().removeIf(time -> time < now);
		}
		final Long allowed = allowedUntil.get(player.method_5667());
		if (allowed != null && now < allowed) {
			return;
		}
		final class_2350 facing = state.method_11654(TicketGateBlock.FACING);
		final double fx = facing.method_10148();
		final double fz = facing.method_10165();
		final class_243 center = class_243.method_24953(pos);
		final double along = (player.method_23317() - center.field_1352) * fx + (player.method_23321() - center.field_1350) * fz;
		final boolean inbound = along <= 0.35;

		final Long denied = deniedUntil.get(player.method_5667());
		if (denied != null && now < denied) {
			pushBack(player, center, fx, fz, inbound);
			return;
		}

		final TicketingManager manager = Mtr12306.manager();
		if (manager == null) {
			return;
		}
		syncBinding();
		final Checkpoint checkpoint = manager.data().checkpoint(checkpointId);

		// 出站闸机：只放行从站台侧走出来的人，并记录出闸
		if ("EXIT".equals(mode)) {
			if (inbound) {
				pushBack(player, center, fx, fz, true);
				notify(player, "§c此闸机仅限出站，请走进站闸机", 2000L);
				return;
			}
			if (checkpoint != null) {
				manager.markExits(player.method_7334().getName(), checkpoint.stationId, checkpointId);
			}
			allow(world, pos, state, player);
			world.method_8396(null, pos, class_3417.field_15082, class_3419.field_15245, 0.6F, 1.5F);
			player.method_7353(class_2561.method_43470("§a出站成功 §7| 感谢乘坐"), true);
			return;
		}

		if (checkpoint == null) {
			notify(player, "§c此闸机尚未绑定检票口，请用配置面板右键设置", 4000L);
			return;
		}

		// 换乘闸机：出闸 + 接续车次检票，一次完成
		if ("TRANSFER".equals(mode)) {
			final TicketingManager.TransferResult result = manager.transfer(player.method_7334().getName(), checkpoint);
			if (!result.allow) {
				deny(world, pos, state, player, center, fx, fz, true, result.reason);
				return;
			}
			allow(world, pos, state, player);
			world.method_8396(null, pos, class_3417.field_15082, class_3419.field_15245, 0.7F, 1.5F);
			world.method_8396(null, pos, class_3417.field_14627, class_3419.field_15245, 0.6F, 1.2F);
			world.method_14199(class_2398.field_11211, center.field_1352, pos.method_10264() + 1.0, center.field_1350, 12, 0.3, 0.4, 0.3, 0.02);
			player.field_13987.method_14364(new class_5904(class_2561.method_43470("§a换乘成功")));
			player.field_13987.method_14364(new class_5903(class_2561.method_43470(result.nextSegment)));
			player.field_13987.method_14364(new class_5905(4, 70, 10));
			if (!result.arrivingSegment.isEmpty()) {
				player.method_7353(class_2561.method_43470("§a✔ " + result.arrivingSegment), false);
			}
			player.method_7353(class_2561.method_43470("§a✔ " + result.nextSegment), false);
			player.method_7353(class_2561.method_43470("§7票号 " + result.next.id + "  检票口 " + result.checkpointName), false);
			return;
		}

		if (!inbound) {
			// 站台侧进入：只有双向闸机才处理（出站方向）
			if (!"BOTH".equals(mode)) {
				pushBack(player, center, fx, fz, false);
				notify(player, "§c此闸机仅限进站", 2000L);
				return;
			}
			if (manager.hasBoardedToday(player.method_7334().getName())) {
				manager.markExits(player.method_7334().getName(), checkpoint.stationId, checkpointId);
				allow(world, pos, state, player);
				world.method_8396(null, pos, class_3417.field_15082, class_3419.field_15245, 0.6F, 1.5F);
				player.method_7353(class_2561.method_43470("§a出站成功 §7| 感谢乘坐"), true);
			} else {
				deny(world, pos, state, player, center, fx, fz, false, "今日没有已检票的车票，无法出站");
			}
			return;
		}

		// 进站方向：正常检票
		final TicketingManager.CheckResult result = manager.checkPlayer(player.method_7334().getName(), checkpoint, true);
		if (result.allow) {
			allow(world, pos, state, player);
			world.method_8396(null, pos, class_3417.field_15082, class_3419.field_15245, 0.7F, 1.5F);
			world.method_8396(null, pos, class_3417.field_14627, class_3419.field_15245, 0.6F, 1.2F);
			world.method_14199(class_2398.field_11211, center.field_1352, pos.method_10264() + 1.0, center.field_1350, 10, 0.3, 0.4, 0.3, 0.02);
			player.field_13987.method_14364(new class_5904(class_2561.method_43470("§a检票通过")));
			player.field_13987.method_14364(new class_5903(class_2561.method_43470(result.segment)));
			player.field_13987.method_14364(new class_5905(4, 60, 10));
			player.method_7353(class_2561.method_43470("§a✔ 检票成功 §7| §f" + result.serviceNumber + " 次 §7| §f"
					+ result.seatClassLabel + " " + result.seat + " §7| 票价 " + result.price + " 元"), false);
			player.method_7353(class_2561.method_43470("§f" + result.segment), false);
			player.method_7353(class_2561.method_43470("§7票号 " + result.ticket.id + "  检票口 " + result.checkpointName), false);
		} else {
			deny(world, pos, state, player, center, fx, fz, true, result.reason);
		}
	}

	private void allow(final class_3218 world, final class_2338 pos, final class_2680 state,
			final class_3222 player) {
		allowedUntil.put(player.method_5667(), System.currentTimeMillis() + OPEN_TICKS * 50L);
		deniedUntil.remove(player.method_5667());
		world.method_8652(pos, state.method_11657(TicketGateBlock.OPEN, TicketGateBlock.GateState.OPEN), 3);
		world.method_39279(pos, state.method_26204(), OPEN_TICKS);
	}

	private void deny(final class_3218 world, final class_2338 pos, final class_2680 state,
			final class_3222 player, final class_243 center, final double fx, final double fz,
			final boolean inbound, final String reason) {
		deniedUntil.put(player.method_5667(), System.currentTimeMillis() + 1500L);
		world.method_8652(pos, state.method_11657(TicketGateBlock.OPEN, TicketGateBlock.GateState.PENDING), 3);
		world.method_39279(pos, state.method_26204(), DENY_TICKS);
		world.method_8396(null, pos, class_3417.field_15008, class_3419.field_15245, 0.7F, 1.0F);
		world.method_14199(class_2398.field_11251, center.field_1352, pos.method_10264() + 1.0, center.field_1350, 6, 0.2, 0.2, 0.2, 0.01);
		pushBack(player, center, fx, fz, inbound);
		notify(player, "§c✘ 检票失败：" + reason, 1500L);
	}

	/** 把玩家推回进入前那一侧（闸机只挡机柜，需要主动推回） */
	private void pushBack(final class_3222 player, final class_243 center, final double fx, final double fz,
			final boolean inbound) {
		final double sign = inbound ? -1.0D : 1.0D;
		player.method_5859(center.field_1352 + fx * 1.15 * sign, player.method_23318(), center.field_1350 + fz * 1.15 * sign);
		player.method_18799(class_243.field_1353);
		player.field_6037 = true;
	}

	private void notify(final class_3222 player, final String message, final long cooldownMillis) {
		final long now = System.currentTimeMillis();
		final Long last = messageCooldown.get(player.method_5667());
		if (last != null && now < last) {
			return;
		}
		messageCooldown.put(player.method_5667(), now + cooldownMillis);
		player.method_7353(class_2561.method_43470(message), true);
	}
}
