package com.mtr12306.net;

import com.google.gson.JsonObject;
import com.mtr12306.Mtr12306;
import com.mtr12306.TicketingManager;
import com.mtr12306.block.GateHelper;
import com.mtr12306.block.TicketGateBlockEntity;
import com.mtr12306.data.Checkpoint;
import com.mtr12306.data.Station;
import com.mtr12306.mtr.MtrIntegration;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;

/**
 * 闸机配置界面的网络通信。
 */
public final class ModNetworking {
	public static final class_2960 OPEN_GATE_CONFIG = Mtr12306.id("open_gate_config");
	public static final class_2960 BIND_GATE = Mtr12306.id("bind_gate");

	private ModNetworking() {
	}

	public static void registerCommon() {
		ServerPlayNetworking.registerGlobalReceiver(BIND_GATE, (server, player, handler, buf, responseSender) -> {
			final class_2338 pos = buf.method_10811();
			final String checkpointId = buf.method_10800(32767);
			final String mode = buf.method_10800(16);
			server.execute(() -> applyBinding(player, pos, checkpointId, mode));
		});
	}

	private static void applyBinding(final class_3222 player, final class_2338 pos, final String checkpointId,
			final String mode) {
		if (!player.method_5687(2)) {
			player.method_7353(class_2561.method_43470("§c配置闸机需要 OP 权限"), false);
			return;
		}
		if (!(player.method_37908().method_8321(pos) instanceof TicketGateBlockEntity gate)) {
			return;
		}
		final TicketingManager manager = Mtr12306.manager();
		if (manager == null) {
			return;
		}
		if (!checkpointId.isEmpty()) {
			final Checkpoint checkpoint = manager.data().checkpoint(checkpointId);
			if (checkpoint == null) {
				player.method_7353(class_2561.method_43470("§c检票口不存在: " + checkpointId), false);
				return;
			}
			// 只能绑定闸机所在 MTR 车站的检票口
			final String stationName = MtrIntegration.stationNameAt(GateHelper.dimension(player.method_37908()),
					pos.method_10263(), pos.method_10264(), pos.method_10260());
			final com.google.gson.JsonArray allowed = manager.checkpointsForStationName(stationName);
			boolean found = false;
			for (final com.google.gson.JsonElement element : allowed) {
				final JsonObject entry = element.getAsJsonObject();
				if (entry.get("id").getAsString().equals(checkpointId)) {
					found = true;
					break;
				}
			}
			if (!found) {
				player.method_7353(class_2561.method_43470("§c该检票口不在本闸机所在的车站内"
						+ (stationName.isEmpty() ? "（闸机不在任何 MTR 车站范围内）" : "（车站：" + stationName + "）")), false);
				return;
			}
		}
		gate.setCheckpoint(checkpointId, mode);
		gate.syncBinding();
		player.method_7353(class_2561.method_43470("§a闸机已更新：检票口 §e" + gate.checkpointName() + " §a模式 §e" + gate.mode()), false);
	}

	/** 打开闸机配置界面：检票口列表按闸机所在 MTR 车站过滤 */
	public static void openGateConfig(final class_3222 player, final TicketGateBlockEntity gate) {
		final TicketingManager manager = Mtr12306.manager();
		if (manager == null) {
			return;
		}
		final class_2338 pos = gate.method_11016();
		final String stationName = MtrIntegration.stationNameAt(GateHelper.dimension(player.method_37908()),
				pos.method_10263(), pos.method_10264(), pos.method_10260());
		final com.google.gson.JsonArray allowed = manager.checkpointsForStationName(stationName);

		final class_2540 buf = PacketByteBufs.create();
		buf.method_10807(pos);
		buf.method_10814(gate.checkpointId());
		buf.method_10814(gate.mode());
		buf.method_10814(stationName);
		buf.writeInt(allowed.size());
		for (final com.google.gson.JsonElement element : allowed) {
			final JsonObject entry = element.getAsJsonObject();
			buf.method_10814(entry.get("id").getAsString());
			final String platforms = entry.get("platforms").getAsString();
			buf.method_10814(entry.get("station").getAsString() + " · " + entry.get("name").getAsString()
					+ (platforms.isBlank() ? "" : "（站台 " + platforms + "）"));
		}
		ServerPlayNetworking.send(player, OPEN_GATE_CONFIG, buf);
	}

	@SuppressWarnings("unused")
	private static String stationName(final Checkpoint checkpoint, final TicketingManager manager) {
		final Station station = manager.data().station(checkpoint.stationId);
		return station == null ? "" : station.name;
	}
}
