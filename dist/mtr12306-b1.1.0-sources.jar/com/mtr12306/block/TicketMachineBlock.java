package com.mtr12306.block;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2464;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2753;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import org.jetbrains.annotations.Nullable;

/**
 * 售票机：模型沿用 MTR 的 ticket_machine。
 * 右键打开界面：购买车票（需要 mtr12306 账号）与打印报销凭证。
 */
public class TicketMachineBlock extends class_2237 {
	public static final class_2753 FACING = class_2383.field_11177;
	private static final class_265 SHAPE = class_2248.method_9541(0.0, 0.0, 4.0, 16.0, 16.0, 16.0);

	public TicketMachineBlock(final class_2251 settings) {
		super(settings);
		method_9590(method_9564().method_11657(FACING, class_2350.field_11043));
	}

	@Override
	protected void method_9515(final class_2689.class_2690<class_2248, class_2680> builder) {
		builder.method_11667(FACING);
	}

	@Override
	public class_2680 method_9605(final class_1750 ctx) {
		return method_9564().method_11657(FACING, ctx.method_8042().method_10153());
	}

	@Override
	public class_2464 method_9604(final class_2680 state) {
		return class_2464.field_11458;
	}

	@Override
	public class_265 method_9530(final class_2680 state, final class_1922 world, final class_2338 pos,
			final class_3726 context) {
		return SHAPE;
	}

	@Nullable
	@Override
	public class_2586 method_10123(final class_2338 pos, final class_2680 state) {
		return new TicketMachineBlockEntity(pos, state);
	}

	@Override
	public class_1269 method_9534(final class_2680 state, final class_1937 world, final class_2338 pos, final class_1657 player,
			final class_1268 hand, final class_3965 hit) {
		if (world.method_8608()) {
			return class_1269.field_5812;
		}
		if (!(player instanceof class_3222 serverPlayer) || !(world instanceof class_3218 serverWorld)) {
			return class_1269.field_5811;
		}
		if (!(world.method_8321(pos) instanceof TicketMachineBlockEntity machine)) {
			return class_1269.field_5811;
		}
		com.mtr12306.net.ModNetworking.openMachine(serverPlayer, pos, machine.stationId(serverWorld, pos));
		serverPlayer.method_7353(class_2561.method_43470("§7售票机 · 可购票与打印报销凭证（需账号）"), true);
		return class_1269.field_5812;
	}
}
