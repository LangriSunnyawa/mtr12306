package com.mtr12306.block;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.mtr12306.Mtr12306;
import com.mtr12306.TicketingManager;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

/**
 * 广播器方块实体：按车站/检票口筛选，自动播报「正在检票」的车次（京张广播格式）。
 * 文案与音效可在 config/broadcast.json 中覆盖。
 */
public class BroadcasterBlockEntity extends class_2586 {
	private static final int INTERVAL_TICKS = 20 * 25;
	private static final double RADIUS = 64.0D;

	private String stationId = "";
	private List<String> checkpointIds = new ArrayList<>();
	private String lastBroadcast = "";
	private int cooldown = 0;

	public BroadcasterBlockEntity(final class_2338 pos, final class_2680 state) {
		super(ModBlocks.BROADCASTER_ENTITY, pos, state);
	}

	public String stationId() {
		return stationId;
	}

	public List<String> checkpointIds() {
		return checkpointIds;
	}

	public void setBinding(final String stationId, final List<String> checkpointIds) {
		this.stationId = stationId == null ? "" : stationId;
		this.checkpointIds = checkpointIds == null ? new ArrayList<>() : new ArrayList<>(checkpointIds);
		method_5431();
	}

	public String bindingLabel() {
		final TicketingManager manager = Mtr12306.manager();
		if (manager == null || stationId.isEmpty()) {
			return "未绑定车站";
		}
		return manager.checkpointLabel(stationId, checkpointIds);
	}

	public void serverTick(final class_3218 world, final class_2338 pos) {
		if (cooldown > 0) {
			cooldown--;
			return;
		}
		cooldown = INTERVAL_TICKS;
		if (stationId.isEmpty() || Mtr12306.manager() == null) {
			return;
		}
		final JsonArray rows = Mtr12306.manager().boardRows(stationId, checkpointIds);
		String chosen = null;
		JsonObject chosenRow = null;
		for (int i = 0; i < rows.size(); i++) {
			final JsonObject row = rows.get(i).getAsJsonObject();
			if (row.has("boarding") && row.get("boarding").getAsBoolean()) {
				final String service = row.get("service").getAsString();
				if (!service.equals(lastBroadcast)) {
					chosen = service;
					chosenRow = row;
					break;
				}
			}
		}
		if (chosen == null || chosenRow == null) {
			return;
		}
		lastBroadcast = chosen;
		broadcast(world, pos, class_2561.method_43470(Mtr12306.CONFIG.broadcastPrefix
				+ chosen + "次列车开始检票，请到" + chosenRow.get("platform").getAsString() + "站台检票上车。"
				+ Mtr12306.CONFIG.broadcastSuffix));
	}

	private void broadcast(final class_3218 world, final class_2338 pos, final class_2561 message) {
		world.method_8396(null, pos, class_3417.field_14793.comp_349(), class_3419.field_15245, 1.0F, 1.6F);
		world.method_8396(null, pos, class_3417.field_14725.comp_349(), class_3419.field_15245, 0.9F, 1.2F);
		for (final class_3222 player : world.method_18766(candidate ->
				candidate.method_19538().method_1028(pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5)
						<= RADIUS * RADIUS)) {
			TicketGateBlockEntity.safeMessage(player, class_2561.method_43470("§b[车站广播] §f" + message.getString()), false);
		}
	}

	@Override
	public void method_11007(final class_2487 nbt) {
		super.method_11007(nbt);
		nbt.method_10582("stationId", stationId);
		final class_2499 list = new class_2499();
		for (final String id : checkpointIds) {
			list.add(class_2519.method_23256(id));
		}
		nbt.method_10566("checkpointIds", list);
	}

	@Override
	public void method_11014(final class_2487 nbt) {
		super.method_11014(nbt);
		stationId = nbt.method_10558("stationId");
		checkpointIds = new ArrayList<>();
		if (nbt.method_10573("checkpointIds", class_2520.field_33259)) {
			final class_2499 list = nbt.method_10554("checkpointIds", class_2520.field_33258);
			for (int i = 0; i < list.size(); i++) {
				checkpointIds.add(list.method_10608(i));
			}
		}
	}

	@Override
	public class_2487 method_16887() {
		return method_38244();
	}

	@SuppressWarnings("unused")
	private static class_238 unusedBox() {
		return new class_238(0, 0, 0, 1, 1, 1);
	}
}
