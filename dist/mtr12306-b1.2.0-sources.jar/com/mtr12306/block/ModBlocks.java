package com.mtr12306.block;

import com.mtr12306.Mtr12306;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_2591;
import net.minecraft.class_7923;

public final class ModBlocks {
	public static final class_2248 TICKET_GATE = new TicketGateBlock(
			FabricBlockSettings.method_9637().method_9629(2.0F, 6.0F).method_9626(class_2498.field_11533).method_22488().method_29292()
	);

	public static final class_2591<TicketGateBlockEntity> TICKET_GATE_ENTITY = FabricBlockEntityTypeBuilder
			.create(TicketGateBlockEntity::new, TICKET_GATE)
			.build();

	public static final class_2248 TICKET_MACHINE = new TicketMachineBlock(
			FabricBlockSettings.method_9637().method_9629(2.0F, 6.0F).method_9626(class_2498.field_11533).method_22488().method_29292()
	);

	public static final class_2591<TicketMachineBlockEntity> TICKET_MACHINE_ENTITY = FabricBlockEntityTypeBuilder
			.create(TicketMachineBlockEntity::new, TICKET_MACHINE)
			.build();

	public static final class_2248 STATION_BOARD = new StationBoardBlock(
			FabricBlockSettings.method_9637().method_9629(1.5F, 6.0F).method_9626(net.minecraft.class_2498.field_11533)
					.method_22488().method_29292()
	);

	public static final class_2591<StationBoardBlockEntity> STATION_BOARD_ENTITY = FabricBlockEntityTypeBuilder
			.create(StationBoardBlockEntity::new, STATION_BOARD)
			.build();

	public static final class_2248 BROADCASTER = new BroadcasterBlock(
			FabricBlockSettings.method_9637().method_9629(1.5F, 6.0F).method_9626(class_2498.field_11533).method_22488().method_29292()
	);

	public static final class_2591<BroadcasterBlockEntity> BROADCASTER_ENTITY = FabricBlockEntityTypeBuilder
			.create(BroadcasterBlockEntity::new, BROADCASTER)
			.build();

	private ModBlocks() {
	}

	public static void register() {
		class_2378.method_10230(class_7923.field_41175, Mtr12306.id("ticket_gate"), TICKET_GATE);
		class_2378.method_10230(class_7923.field_41181, Mtr12306.id("ticket_gate"), TICKET_GATE_ENTITY);
		class_2378.method_10230(class_7923.field_41175, Mtr12306.id("ticket_machine"), TICKET_MACHINE);
		class_2378.method_10230(class_7923.field_41181, Mtr12306.id("ticket_machine"), TICKET_MACHINE_ENTITY);
		class_2378.method_10230(class_7923.field_41175, Mtr12306.id("station_board"), STATION_BOARD);
		class_2378.method_10230(class_7923.field_41181, Mtr12306.id("station_board"), STATION_BOARD_ENTITY);
		class_2378.method_10230(class_7923.field_41175, Mtr12306.id("broadcaster"), BROADCASTER);
		class_2378.method_10230(class_7923.field_41181, Mtr12306.id("broadcaster"), BROADCASTER_ENTITY);
	}
}
