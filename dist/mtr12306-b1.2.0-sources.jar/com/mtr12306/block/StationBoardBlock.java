package com.mtr12306.block;

import com.mtr12306.Mtr12306;
import com.mtr12306.item.ConfigToolItem;
import com.mtr12306.net.ModNetworking;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2464;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2746;
import net.minecraft.class_2753;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import org.jetbrains.annotations.Nullable;

/**
 * 车站大屏：可自由拼接成矩形的多格屏幕。
 * 只由「锚点」（MAIN）方块负责渲染整块画面，其余方块不渲染内容，因此开销与普通方块相同。
 */
public class StationBoardBlock extends class_2237 {
	public static final class_2753 FACING = class_2383.field_11177;
	/** 是否为该屏幕的锚点（记录尺寸并负责渲染） */
	public static final class_2746 MAIN = class_2746.method_11825("main");

	private static final class_265 SHAPE = class_2248.method_9541(0.0, 0.0, 14.0, 16.0, 16.0, 16.0);

	public StationBoardBlock(final class_2251 settings) {
		super(settings);
		method_9590(method_9564().method_11657(FACING, class_2350.field_11043).method_11657(MAIN, true));
	}

	@Override
	protected void method_9515(final class_2689.class_2690<class_2248, class_2680> builder) {
		builder.method_11667(FACING, MAIN);
	}

	@Override
	public class_2680 method_9605(final class_1750 ctx) {
		return method_9564().method_11657(FACING, ctx.method_8042().method_10153()).method_11657(MAIN, true);
	}

	@Override
	public class_2464 method_9604(final class_2680 state) {
		return class_2464.field_11458;
	}

	@Override
	public class_265 method_9530(final class_2680 state, final class_1922 world, final class_2338 pos,
			final class_3726 context) {
		return SHAPE;
	}

	@Override
	public class_265 method_9549(final class_2680 state, final class_1922 world, final class_2338 pos,
			final class_3726 context) {
		return SHAPE;
	}

	@Nullable
	@Override
	public class_2586 method_10123(final class_2338 pos, final class_2680 state) {
		return new StationBoardBlockEntity(pos, state);
	}

	@Override
	public void method_9567(final class_1937 world, final class_2338 pos, final class_2680 state, @Nullable final class_1309 placer,
			final class_1799 itemStack) {
		super.method_9567(world, pos, state, placer, itemStack);
		if (world.method_8608() || !(world.method_8321(pos) instanceof StationBoardBlockEntity board)) {
			return;
		}
		board.setAnchor(pos);
		board.method_5431();
	}

	@Override
	public void method_9536(final class_2680 state, final class_1937 world, final class_2338 pos, final class_2680 newState,
			final boolean moved) {
		if (!world.method_8608() && !state.method_27852(newState.method_26204())) {
			if (world.method_8321(pos) instanceof StationBoardBlockEntity board) {
				board.removeWholeBoard((class_3218) world);
			}
		}
		super.method_9536(state, world, pos, newState, moved);
	}

	@Override
	public class_1269 method_9534(final class_2680 state, final class_1937 world, final class_2338 pos, final class_1657 player,
			final class_1268 hand, final class_3965 hit) {
		if (world.method_8608()) {
			return class_1269.field_5812;
		}
		if (!(player instanceof class_3222 serverPlayer)) {
			return class_1269.field_5811;
		}
		if (!(world.method_8321(pos) instanceof StationBoardBlockEntity board)) {
			return class_1269.field_5811;
		}
		if (player.method_5998(hand).method_7909() instanceof ConfigToolItem && serverPlayer.method_5687(2)) {
			ModNetworking.openBoardConfig(serverPlayer, board);
			return class_1269.field_5812;
		}
		serverPlayer.method_7353(class_2561.method_43470("§e大屏：§f" + board.bindingLabel() + " §7尺寸 §f"
				+ board.width() + "×" + board.height() + " §7（用配置面板右键可调整）"), false);
		return class_1269.field_5812;
	}

	@SuppressWarnings("unused")
	private static void unused() {
		Mtr12306.LOGGER.getName();
	}
}
