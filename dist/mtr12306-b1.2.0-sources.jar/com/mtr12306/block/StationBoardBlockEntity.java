package com.mtr12306.block;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.mtr12306.Mtr12306;
import com.mtr12306.TicketingManager;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2520;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3218;

/**
 * 车站大屏方块实体：锚点记录整块矩形的尺寸与筛选条件；其余格子共享同一份数据。
 */
public class StationBoardBlockEntity extends class_2586 {
	private class_2338 anchor = class_2338.field_10980;
	private int width = 1;
	private int height = 1;
	private String stationId = "";
	private List<String> checkpointIds = new ArrayList<>();

	public StationBoardBlockEntity(final class_2338 pos, final class_2680 state) {
		super(ModBlocks.STATION_BOARD_ENTITY, pos, state);
		anchor = pos;
	}

	public class_2338 anchor() {
		return anchor;
	}

	public int width() {
		return width;
	}

	public int heightValue() {
		return height;
	}

	public int height() {
		return height;
	}

	public String stationId() {
		return stationId;
	}

	public List<String> checkpointIds() {
		return checkpointIds;
	}

	public void setAnchor(final class_2338 anchor) {
		this.anchor = anchor;
	}

	public void setBinding(final String stationId, final List<String> checkpointIds) {
		this.stationId = stationId == null ? "" : stationId;
		this.checkpointIds = checkpointIds == null ? new ArrayList<>() : new ArrayList<>(checkpointIds);
		method_5431();
	}

	public String bindingLabel() {
		final TicketingManager manager = Mtr12306.manager();
		if (manager == null || stationId.isEmpty()) {
			return "未绑定车站";
		}
		return manager.checkpointLabel(stationId, checkpointIds);
	}

	/** 本屏幕显示的行数据（服务端计算后同步给客户端渲染） */
	public JsonArray rows() {
		final TicketingManager manager = Mtr12306.manager();
		if (manager == null || stationId.isEmpty()) {
			return new JsonArray();
		}
		return manager.boardRows(stationId, checkpointIds);
	}

	public JsonObject renderPayload() {
		final JsonObject json = new JsonObject();
		json.addProperty("width", width);
		json.addProperty("height", height);
		json.addProperty("station", bindingLabel());
		json.add("rows", rows());
		return json;
	}

	/* ------------------------------------------------------------------ 多格矩形 */

	/** 水平展开方向（屏幕“向右”扩展的轴向） */
	public class_2350 rightDirection() {
		final class_2350 facing = method_11010().method_11654(StationBoardBlock.FACING);
		return facing.method_10166() == class_2350.class_2351.field_11051
				? (facing == class_2350.field_11043 ? class_2350.field_11034 : class_2350.field_11039)
				: (facing == class_2350.field_11034 ? class_2350.field_11035 : class_2350.field_11043);
	}

	public String rightDirectionName() {
		return rightDirection().method_15434();
	}

	/**
	 * 设置屏幕尺寸：以锚点为左下角，向右（rightDirection）、向上扩展。
	 * 只允许在整块矩形都为空气或本屏幕方块时生效。
	 */
	public boolean applySize(final class_3218 world, final int newWidth, final int newHeight, final String stationId,
			final List<String> checkpointIds) {
		final int w = Math.max(1, Math.min(12, newWidth));
		final int h = Math.max(1, Math.min(8, newHeight));
		final class_2350 right = rightDirection();
		final class_2338 base = anchor;

		// 1) 检查目标区域是否可用
		for (int dx = 0; dx < w; dx++) {
			for (int dy = 0; dy < h; dy++) {
				final class_2338 target = base.method_10079(right, dx).method_10086(dy);
				final class_2680 state = world.method_8320(target);
				final boolean ours = state.method_27852(ModBlocks.STATION_BOARD);
				if (!state.method_26215() && !ours) {
					return false;
				}
			}
		}

		// 2) 清掉旧的格子（锚点保留）
		removeCells(world, base, method_11010().method_11654(StationBoardBlock.FACING));

		// 3) 铺新矩形
		final class_2680 baseState = world.method_8320(base);
		final class_2350 facing = baseState.method_11654(StationBoardBlock.FACING);
		for (int dx = 0; dx < w; dx++) {
			for (int dy = 0; dy < h; dy++) {
				final class_2338 target = base.method_10079(right, dx).method_10086(dy);
				final class_2680 cellState = baseState
						.method_11657(StationBoardBlock.MAIN, dx == 0 && dy == 0)
						.method_11657(StationBoardBlock.FACING, facing);
				world.method_8652(target, cellState, class_2248.field_31036);
				if (world.method_8321(target) instanceof StationBoardBlockEntity cell) {
					cell.anchor = base;
					cell.width = w;
					cell.height = h;
					cell.setBinding(stationId, checkpointIds);
					cell.method_5431();
				}
			}
		}
		if (world.method_8321(base) instanceof StationBoardBlockEntity cell) {
			cell.anchor = base;
			cell.width = w;
			cell.height = h;
			cell.setBinding(stationId, checkpointIds);
			cell.method_5431();
		}
		world.method_8413(base, baseState, world.method_8320(base), class_2248.field_31036);
		return true;
	}

	/** 清掉以 base/facing 为前提、当前尺寸覆盖的所有非锚点格子 */
	private void removeCells(final class_3218 world, final class_2338 base, final class_2350 facing) {
		final class_2350 right = rightDirection();
		for (int dx = 0; dx < width; dx++) {
			for (int dy = 0; dy < height; dy++) {
				if (dx == 0 && dy == 0) {
					continue;
				}
				final class_2338 target = base.method_10079(right, dx).method_10086(dy);
				if (world.method_8320(target).method_27852(ModBlocks.STATION_BOARD)) {
					world.method_8652(target, net.minecraft.class_2246.field_10124.method_9564(), class_2248.field_31036);
				}
			}
		}
	}

	/** 整块移除（拆任意一格时调用） */
	public void removeWholeBoard(final class_3218 world) {
		final class_2338 base = anchor;
		final class_2350 right = rightDirection();
		for (int dx = 0; dx < width; dx++) {
			for (int dy = 0; dy < height; dy++) {
				final class_2338 target = base.method_10079(right, dx).method_10086(dy);
				if (world.method_8320(target).method_27852(ModBlocks.STATION_BOARD)) {
					world.method_8652(target, net.minecraft.class_2246.field_10124.method_9564(), class_2248.field_31036);
				}
			}
		}
	}

	/* ------------------------------------------------------------------ NBT */

	@Override
	public void method_11007(final class_2487 nbt) {
		super.method_11007(nbt);
		nbt.method_10569("ax", anchor.method_10263());
		nbt.method_10569("ay", anchor.method_10264());
		nbt.method_10569("az", anchor.method_10260());
		nbt.method_10569("w", width);
		nbt.method_10569("h", height);
		nbt.method_10582("stationId", stationId);
		final class_2499 list = new class_2499();
		for (final String id : checkpointIds) {
			list.add(class_2519.method_23256(id));
		}
		nbt.method_10566("checkpointIds", list);
	}

	@Override
	public void method_11014(final class_2487 nbt) {
		super.method_11014(nbt);
		anchor = new class_2338(nbt.method_10550("ax"), nbt.method_10550("ay"), nbt.method_10550("az"));
		width = Math.max(1, nbt.method_10550("w"));
		height = Math.max(1, nbt.method_10550("h"));
		stationId = nbt.method_10558("stationId");
		checkpointIds = new ArrayList<>();
		if (nbt.method_10573("checkpointIds", class_2520.field_33259)) {
			final class_2499 list = nbt.method_10554("checkpointIds", class_2520.field_33258);
			for (int i = 0; i < list.size(); i++) {
				checkpointIds.add(list.method_10608(i));
			}
		}
	}

	@Override
	public class_2487 method_16887() {
		final class_2487 nbt = method_38244();
		// 客户端渲染需要行数据：把渲染载荷塞进同步数据里
		nbt.method_10582("payload", renderPayload().toString());
		return nbt;
	}
}
