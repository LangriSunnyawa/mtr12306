package com.mtr12306.block;

import com.mtr12306.Mtr12306;
import com.mtr12306.item.ConfigToolItem;
import com.mtr12306.net.ModNetworking;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2464;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2753;
import net.minecraft.class_2754;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3542;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_5558;
import net.minecraft.class_5819;
import org.jetbrains.annotations.Nullable;

/**
 * 检票闸机（模型沿用 MTR ticket barrier）。
 *
 * <p>通行方式参考 Metropolis 的闸机：<b>右键闸机</b>才会检票放行；关门时是实心方块，
 * 因此无法"一直往前走卡进去"；放行后闸门打开数秒供通过。</p>
 */
public class TicketGateBlock extends class_2237 {
	public static final class_2753 FACING = class_2383.field_11177;

	public enum GateState implements class_3542 {
		CLOSED("closed"), PENDING("pending"), OPEN("open");

		private final String id;

		GateState(final String id) {
			this.id = id;
		}

		@Override
		public String method_15434() {
			return id;
		}
	}

	public enum GateKind implements class_3542 {
		ENTRANCE("entrance"), EXIT("exit");

		private final String id;

		GateKind(final String id) {
			this.id = id;
		}

		@Override
		public String method_15434() {
			return id;
		}
	}

	public static final class_2754<GateState> OPEN = class_2754.method_11850("open", GateState.class);
	public static final class_2754<GateKind> KIND = class_2754.method_11850("kind", GateKind.class);

	/** 机柜（南北向摆放时位于 X 两侧） */
	private static final class_265 CABINETS_NS = Voxels.union(
			class_2248.method_9541(0.0, 0.0, 4.0, 4.0, 15.0, 12.0),
			class_2248.method_9541(12.0, 0.0, 4.0, 16.0, 15.0, 12.0));
	/** 机柜（东西向摆放时位于 Z 两侧） */
	private static final class_265 CABINETS_EW = Voxels.union(
			class_2248.method_9541(4.0, 0.0, 0.0, 12.0, 15.0, 4.0),
			class_2248.method_9541(4.0, 0.0, 12.0, 12.0, 15.0, 16.0));
	/** 闸板（关门时横挡通道） */
	private static final class_265 PANEL_NS = class_2248.method_9541(4.0, 5.0, 7.6, 12.0, 13.0, 8.4);
	private static final class_265 PANEL_EW = class_2248.method_9541(7.6, 5.0, 4.0, 8.4, 13.0, 12.0);
	/** 底座 */
	private static final class_265 BASE_NS = class_2248.method_9541(0.0, 0.0, 4.0, 16.0, 2.0, 12.0);
	private static final class_265 BASE_EW = class_2248.method_9541(4.0, 0.0, 0.0, 12.0, 2.0, 16.0);

	private static final class_265 CLOSED_NS = Voxels.union(CABINETS_NS, PANEL_NS, BASE_NS);
	private static final class_265 CLOSED_EW = Voxels.union(CABINETS_EW, PANEL_EW, BASE_EW);
	private static final class_265 OPEN_NS = Voxels.union(CABINETS_NS, BASE_NS);
	private static final class_265 OPEN_EW = Voxels.union(CABINETS_EW, BASE_EW);

	private static class_265 shapeFor(final class_2680 state) {
		final boolean alongX = state.method_11654(FACING).method_10166() == class_2350.class_2351.field_11051;
		if (state.method_11654(OPEN) == GateState.OPEN) {
			return alongX ? OPEN_NS : OPEN_EW;
		}
		return alongX ? CLOSED_NS : CLOSED_EW;
	}

	/** 小工具：合并若干形状（等价 VoxelShapes.union，写短一点） */
	private static final class Voxels {
		private static class_265 union(final class_265... shapes) {
			class_265 result = net.minecraft.class_259.method_1073();
			for (final class_265 shape : shapes) {
				result = net.minecraft.class_259.method_1084(result, shape);
			}
			return result.method_1097();
		}
	}

	public TicketGateBlock(final class_2251 settings) {
		super(settings);
		method_9590(method_9564().method_11657(FACING, class_2350.field_11043).method_11657(OPEN, GateState.CLOSED)
				.method_11657(KIND, GateKind.ENTRANCE));
	}

	@Override
	protected void method_9515(final class_2689.class_2690<class_2248, class_2680> builder) {
		builder.method_11667(FACING, OPEN, KIND);
	}

	@Override
	public class_2680 method_9605(final class_1750 ctx) {
		return method_9564().method_11657(FACING, ctx.method_8042());
	}

	@Override
	public class_2464 method_9604(final class_2680 state) {
		return class_2464.field_11458;
	}

	@Override
	public class_265 method_9530(final class_2680 state, final class_1922 world, final class_2338 pos,
			final class_3726 context) {
		return shapeFor(state);
	}

	@Override
	public class_265 method_9549(final class_2680 state, final class_1922 world, final class_2338 pos,
			final class_3726 context) {
		return shapeFor(state);
	}

	@Nullable
	@Override
	public class_2586 method_10123(final class_2338 pos, final class_2680 state) {
		return new TicketGateBlockEntity(pos, state);
	}

	@Nullable
	@Override
	public <T extends class_2586> class_5558<T> method_31645(final class_1937 world, final class_2680 state,
			final class_2591<T> type) {
		if (world.method_8608()) {
			return null;
		}
		return (tickWorld, tickPos, tickState, blockEntity) -> {
			if (blockEntity instanceof TicketGateBlockEntity gate) {
				gate.serverTick(tickWorld, tickPos);
			}
		};
	}

	@Override
	public void method_9588(final class_2680 state, final class_3218 world, final class_2338 pos, final class_5819 random) {
		if (state.method_11654(OPEN) != GateState.CLOSED) {
			world.method_8652(pos, state.method_11657(OPEN, GateState.CLOSED), class_2248.field_31028);
		}
	}

	@Override
	public void method_9567(final class_1937 world, final class_2338 pos, final class_2680 state, @Nullable final class_1309 placer,
			final class_1799 itemStack) {
		super.method_9567(world, pos, state, placer, itemStack);
		if (world.method_8608() || !(world.method_8321(pos) instanceof TicketGateBlockEntity gate)) {
			return;
		}
		// 相邻闸机自动继承车站/检票口/模式，方便成排布置
		for (final class_2350 direction : class_2350.class_2353.field_11062) {
			final class_2586 neighbour = world.method_8321(pos.method_10093(direction));
			if (neighbour instanceof TicketGateBlockEntity other && !other.stationId().isEmpty()) {
				gate.setBinding(other.stationId(), other.checkpointIds(), other.mode());
				break;
			}
		}
		gate.syncBinding();
	}

	@Override
	public void method_9536(final class_2680 state, final class_1937 world, final class_2338 pos, final class_2680 newState,
			final boolean moved) {
		if (!world.method_8608() && !state.method_27852(newState.method_26204()) && Mtr12306.manager() != null) {
			Mtr12306.manager().removeGate(GateHelper.key(world, pos));
		}
		super.method_9536(state, world, pos, newState, moved);
	}

	@Override
	public class_1269 method_9534(final class_2680 state, final class_1937 world, final class_2338 pos, final class_1657 player,
			final class_1268 hand, final class_3965 hit) {
		if (world.method_8608()) {
			return class_1269.field_5812;
		}
		if (!(player instanceof class_3222 serverPlayer)) {
			return class_1269.field_5811;
		}
		if (!(world.method_8321(pos) instanceof TicketGateBlockEntity gate)) {
			return class_1269.field_5811;
		}
		gate.syncBinding();
		final boolean withTool = player.method_5998(hand).method_7909() instanceof ConfigToolItem;
		if (withTool && serverPlayer.method_5687(2)) {
			ModNetworking.openGateConfig(serverPlayer, gate);
			return class_1269.field_5812;
		}
		// 普通右键：检票放行（Metropolis 风格）
		gate.tryPass((class_3218) world, pos, state, serverPlayer);
		return class_1269.field_5812;
	}

	/** 兼容旧调用：显示闸机信息 */
	public static class_2561 infoText(final TicketGateBlockEntity gate) {
		return class_2561.method_43470("§e此闸机：§f" + gate.bindingLabel() + " §7模式 §f" + gate.mode());
	}
}
