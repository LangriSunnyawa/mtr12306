package com.mtr12306.block;

import com.mtr12306.Mtr12306;
import com.mtr12306.TicketingManager;
import com.mtr12306.data.Checkpoint;
import com.mtr12306.data.Ticket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5903;
import net.minecraft.class_5904;
import net.minecraft.class_5905;

/**
 * 闸机方块实体：保存所属车站 / 检票口（可多选，空=不限）/ 通行模式，
 * 并在玩家右键时完成检票放行。
 */
public class TicketGateBlockEntity extends class_2586 {
	private static final long MESSAGE_COOLDOWN = 1200L;

	private String stationId = "";
	/** 检票口 id 列表（空 = 不限） */
	private List<String> checkpointIds = new ArrayList<>();
	private String mode = "ENTRY";

	private final Map<UUID, Long> allowedUntil = new HashMap<>();
	private final Map<UUID, Long> deniedUntil = new HashMap<>();
	private final Map<UUID, Long> messageCooldown = new HashMap<>();
	/** 开门/红箭状态的到期时间（毫秒），由 tick 复位，避免卡住 */
	private long closeAt = 0L;
	private boolean tickerLogged = false;

	public TicketGateBlockEntity(final class_2338 pos, final class_2680 state) {
		super(ModBlocks.TICKET_GATE_ENTITY, pos, state);
	}

	/* ------------------------------------------------------------------ 属性 */

	public String stationId() {
		return stationId;
	}

	public List<String> checkpointIds() {
		return checkpointIds;
	}

	public String mode() {
		return mode;
	}

	public void setBinding(final String stationId, final List<String> checkpointIds, final String mode) {
		this.stationId = stationId == null ? "" : stationId;
		this.checkpointIds = checkpointIds == null ? new ArrayList<>() : new ArrayList<>(checkpointIds);
		this.mode = mode == null || mode.isBlank() ? "ENTRY" : mode.toUpperCase();
		method_5431();
		applyKind();
	}

	/** 兼容旧调用（单检票口） */
	public void setCheckpoint(final String checkpointId, final String mode) {
		final TicketingManager manager = Mtr12306.manager();
		String station = stationId;
		final List<String> list = new ArrayList<>();
		if (checkpointId != null && !checkpointId.isEmpty()) {
			list.add(checkpointId);
			if (manager != null) {
				final Checkpoint checkpoint = manager.data().checkpoint(checkpointId);
				if (checkpoint != null) {
					station = checkpoint.stationId;
				}
			}
		}
		setBinding(station, list, mode);
	}

	private void applyKind() {
		if (field_11863 == null || field_11863.method_8608()) {
			return;
		}
		final class_2680 state = field_11863.method_8320(field_11867);
		if (!state.method_28498(TicketGateBlock.KIND)) {
			return;
		}
		final boolean exitLike = "EXIT".equals(mode) || "TRANSFER".equals(mode) || "VALIDATE".equals(mode);
		final TicketGateBlock.GateKind kind = exitLike
				? TicketGateBlock.GateKind.EXIT : TicketGateBlock.GateKind.ENTRANCE;
		if (state.method_11654(TicketGateBlock.KIND) != kind) {
			field_11863.method_8652(field_11867, state.method_11657(TicketGateBlock.KIND, kind), 3);
		}
	}

	public String bindingLabel() {
		final TicketingManager manager = Mtr12306.manager();
		if (manager == null || stationId.isEmpty()) {
			return "未绑定车站";
		}
		return manager.checkpointLabel(stationId, checkpointIds);
	}

	public void syncBinding() {
		if (field_11863 == null) {
			return;
		}
		final TicketingManager manager = Mtr12306.manager();
		if (manager == null) {
			TicketingManager.queueGateRegistration(GateHelper.dimension(field_11863), field_11867.method_10263(), field_11867.method_10264(), field_11867.method_10260(),
					stationId, String.join(",", checkpointIds), mode);
			return;
		}
		manager.bindGateIfAbsent(GateHelper.dimension(field_11863), field_11867.method_10263(), field_11867.method_10264(), field_11867.method_10260(),
				stationId, checkpointIds, mode);
	}

	@Override
	public void method_31662(final class_1937 world) {
		super.method_31662(world);
		if (world != null && !world.method_8608()) {
			syncBinding();
		}
	}

	@Override
	public void method_11007(final class_2487 nbt) {
		super.method_11007(nbt);
		nbt.method_10582("stationId", stationId);
		nbt.method_10582("mode", mode);
		final class_2499 list = new class_2499();
		for (final String id : checkpointIds) {
			list.add(class_2519.method_23256(id));
		}
		nbt.method_10566("checkpointIds", list);
	}

	@Override
	public void method_11014(final class_2487 nbt) {
		super.method_11014(nbt);
		stationId = nbt.method_10558("stationId");
		mode = nbt.method_10545("mode") ? nbt.method_10558("mode") : "ENTRY";
		checkpointIds = new ArrayList<>();
		if (nbt.method_10573("checkpointIds", class_2520.field_33259)) {
			final class_2499 list = nbt.method_10554("checkpointIds", class_2520.field_33258);
			for (int i = 0; i < list.size(); i++) {
				checkpointIds.add(list.method_10608(i));
			}
		} else if (nbt.method_10545("checkpointId")) {
			final String legacy = nbt.method_10558("checkpointId");
			if (!legacy.isEmpty()) {
				checkpointIds.add(legacy);
			}
		}
	}

	@Override
	public class_2487 method_16887() {
		return method_38244();
	}

	/* ------------------------------------------------------------------ 状态复位 */

	public void serverTick(final class_1937 world, final class_2338 pos) {
		if (!(world instanceof class_3218 serverWorld)) {
			return;
		}
		if (!tickerLogged) {
			tickerLogged = true;
			Mtr12306.LOGGER.info("[MTR-12306] 闸机 {} 已开始工作（右键检票模式）", pos.method_23854());
		}
		final class_2680 state = serverWorld.method_8320(pos);
		if (state.method_11654(TicketGateBlock.OPEN) == TicketGateBlock.GateState.CLOSED) {
			closeAt = 0L;
			return;
		}
		final long now = System.currentTimeMillis();
		if (closeAt == 0L) {
			closeAt = now + 5000L;
		}
		if (now >= closeAt) {
			serverWorld.method_8652(pos, state.method_11657(TicketGateBlock.OPEN, TicketGateBlock.GateState.CLOSED), 3);
			closeAt = 0L;
		}
	}

	/* ------------------------------------------------------------------ 右键检票 */

	public void tryPass(final class_3218 world, final class_2338 pos, final class_2680 state,
			final class_3222 player) {
		if (state.method_11654(TicketGateBlock.OPEN) != TicketGateBlock.GateState.CLOSED) {
			notify(player, "§e闸门正在通行，请稍候", 800L);
			return;
		}
		if (player.method_7325()) {
			return;
		}
		final long now = System.currentTimeMillis();
		if (deniedUntil.getOrDefault(player.method_5667(), 0L) > now
				|| allowedUntil.getOrDefault(player.method_5667(), 0L) > now) {
			return;
		}
		final class_2350 facing = state.method_11654(TicketGateBlock.FACING);
		final class_243 center = class_243.method_24953(pos);
		final double along = (player.method_23317() - center.field_1352) * facing.method_10148()
				+ (player.method_23321() - center.field_1350) * facing.method_10165();
		final boolean inbound = along <= 0.35D;

		final Decision decision = decide(world, pos, state, player.method_7334().getName(), inbound, true);
		if (decision.allowed()) {
			allowedUntil.put(player.method_5667(), now + Math.max(1, Mtr12306.CONFIG.gateOpenSeconds) * 1000L);
			deniedUntil.remove(player.method_5667());
			openGate(world, pos, state);
			playAllowEffects(world, pos, player, decision);
		} else {
			deniedUntil.put(player.method_5667(), now + 1500L);
			setPending(world, pos, state);
			world.method_8396(null, pos, class_3417.field_15008, class_3419.field_15245, 0.7F, 1.0F);
			world.method_14199(class_2398.field_11251, center.field_1352, pos.method_10264() + 1.0, center.field_1350, 6, 0.2, 0.2, 0.2, 0.01);
			notify(player, "§c✘ " + decision.message, 1500L);
			Mtr12306.LOGGER.info("[MTR-12306] 闸机 {} 拒绝 {}：{}", pos.method_23854(),
					player.method_7334().getName(), decision.message);
		}
	}

	public static final class Decision {
		public final String action;
		public final String message;
		public final String detail;
		public final String label;

		private Decision(final String action, final String message, final String detail, final String label) {
			this.action = action;
			this.message = message;
			this.detail = detail;
			this.label = label;
		}

		public boolean allowed() {
			return "ALLOW".equals(action);
		}
	}

	private static Decision allow(final String message, final String detail, final String label) {
		return new Decision("ALLOW", message, detail, label);
	}

	private static Decision deny(final String message) {
		return new Decision("DENY", message, "", "");
	}

	/** 判定（供右键与自检命令共用），consume=false 时只读 */
	public Decision decide(final class_1937 world, final class_2338 pos, final class_2680 state, final String playerName,
			final boolean inbound, final boolean consume) {
		final TicketingManager manager = Mtr12306.manager();
		if (manager == null) {
			return deny("购票系统尚未就绪");
		}
		if (stationId.isEmpty()) {
			return deny("此闸机未绑定车站，请用「闸机配置面板」设置");
		}
		final String label = manager.checkpointLabel(stationId, checkpointIds);

		switch (mode) {
			case "VALIDATE" -> {
				if (!consume) {
					final TicketingManager.CheckResult probe = manager.checkEntry(playerName, stationId, checkpointIds, false);
					return allow("核验通过（只读）", probe.resultSummary(), label);
				}
				final var ticket = manager.validateTicket(playerName, Mtr12306.CONFIG.validateHours);
				if (ticket == null) {
					return deny("未查询到 " + Mtr12306.CONFIG.validateHours + " 小时内的有效车票");
				}
				return allow("车票核验通过", ticket.serviceNumber + " 次 " + ticket.date + " "
						+ manager.data().stationName(ticket.fromStationId) + " " + ticket.fromTime + " 开 · "
						+ ticket.seatClassLabel + " " + ticket.seat, label);
			}
			case "EXIT" -> {
				if (inbound) {
					return deny("此闸机仅限出站");
				}
				if (!consume) {
					return allow("可出站（只读）", "出站", label);
				}
				final var ticket = manager.exitLatest(playerName, stationId, checkpointIds);
				if (ticket == null) {
					return deny("没有可出站的车票（需先在本站进站检票）");
				}
				return allow("出站成功", ticket.serviceNumber + " 次 "
						+ manager.data().stationName(ticket.fromStationId) + " → "
						+ manager.data().stationName(ticket.toStationId) + " · " + ticket.seatClassLabel
						+ " " + ticket.seat, label);
			}
			case "TRANSFER" -> {
				if (!inbound) {
					return deny("换乘闸机请从站厅一侧右键");
				}
				final Checkpoint virtual = manager.virtualCheckpoint(stationId, checkpointIds);
				final TicketingManager.TransferResult result = manager.transfer(playerName, virtual, consume);
				if (!result.allow) {
					return deny(result.reason);
				}
				final String detail = (result.arrivingSegment.isEmpty() ? "" : result.arrivingSegment + "\n")
						+ result.nextSegment;
				return allow("换乘成功", detail, label);
			}
			case "BOTH" -> {
				if (!inbound) {
					if (!consume) {
						return allow("可出站（只读）", "出站", label);
					}
					final var ticket = manager.exitLatest(playerName, stationId, checkpointIds);
					if (ticket == null) {
						return deny("没有可出站的车票（需先在本站进站检票）");
					}
					return allow("出站成功", ticket.serviceNumber + " 次 "
							+ manager.data().stationName(ticket.fromStationId) + " → "
							+ manager.data().stationName(ticket.toStationId), label);
				}
				final TicketingManager.CheckResult result = manager.checkEntry(playerName, stationId, checkpointIds, consume);
				return result.allow
						? allow("检票通过", result.serviceNumber + " 次 · " + result.seatClassLabel + " " + result.seat
						+ " · 票价 " + result.price + " 元\n" + result.segment, label)
						: deny(result.reason);
			}
			default -> {
				if (!inbound) {
					return deny("此闸机仅限进站");
				}
				final TicketingManager.CheckResult result = manager.checkEntry(playerName, stationId, checkpointIds, consume);
				return result.allow
						? allow("检票通过", result.serviceNumber + " 次 · " + result.seatClassLabel + " " + result.seat
						+ " · 票价 " + result.price + " 元\n" + result.segment, label)
						: deny(result.reason);
			}
		}
	}

	/* ------------------------------------------------------------------ 效果 */

	private void openGate(final class_3218 world, final class_2338 pos, final class_2680 state) {
		closeAt = System.currentTimeMillis() + Math.max(1, Mtr12306.CONFIG.gateOpenSeconds) * 1000L;
		world.method_8652(pos, state.method_11657(TicketGateBlock.OPEN, TicketGateBlock.GateState.OPEN), 3);
		world.method_39279(pos, state.method_26204(), Math.max(1, Mtr12306.CONFIG.gateOpenSeconds) * 20);
	}

	private void setPending(final class_3218 world, final class_2338 pos, final class_2680 state) {
		closeAt = System.currentTimeMillis() + 1500L;
		world.method_8652(pos, state.method_11657(TicketGateBlock.OPEN, TicketGateBlock.GateState.PENDING), 3);
		world.method_39279(pos, state.method_26204(), 30);
	}

	private void playAllowEffects(final class_3218 world, final class_2338 pos, final class_3222 player,
			final Decision decision) {
		world.method_8396(null, pos, class_3417.field_15082, class_3419.field_15245, 0.7F, 1.5F);
		world.method_8396(null, pos, class_3417.field_14627, class_3419.field_15245, 0.6F, 1.2F);
		world.method_14199(class_2398.field_11211, pos.method_10263() + 0.5, pos.method_10264() + 1.0, pos.method_10260() + 0.5,
				10, 0.3, 0.4, 0.3, 0.02);
		if (player.field_13987 != null) {
			final String[] lines = decision.detail.split("\\n");
			player.field_13987.method_14364(new class_5904(class_2561.method_43470("§a" + decision.message)));
			player.field_13987.method_14364(new class_5903(class_2561.method_43470("§f" + (lines.length > 0 ? lines[0] : decision.label))));
			player.field_13987.method_14364(new class_5905(4, 55, 10));
		}
		for (final String line : decision.detail.split("\\n")) {
			if (!line.isBlank()) {
				safeMessage(player, class_2561.method_43470("§a✔ §f" + line), false);
			}
		}
		safeMessage(player, class_2561.method_43470("§7闸门已开启 " + Mtr12306.CONFIG.gateOpenSeconds + " 秒 · " + decision.label), true);
	}

	public static void safeMessage(final class_3222 player, final class_2561 message, final boolean overlay) {
		if (player.field_13987 != null) {
			player.method_7353(message, overlay);
		}
	}

	private void notify(final class_3222 player, final String message, final long cooldownMillis) {
		final long now = System.currentTimeMillis();
		final Long last = messageCooldown.get(player.method_5667());
		if (last != null && now < last) {
			return;
		}
		messageCooldown.put(player.method_5667(), now + cooldownMillis);
		safeMessage(player, class_2561.method_43470(message), true);
	}
}
