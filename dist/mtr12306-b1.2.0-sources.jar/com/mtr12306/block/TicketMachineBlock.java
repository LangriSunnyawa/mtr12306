package com.mtr12306.block;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2464;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2746;
import net.minecraft.class_2753;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import org.jetbrains.annotations.Nullable;

/**
 * 售票机（两格高，国铁自助售票机样式）。
 * 下半格方块实体保存所属车站；右键打开购票 / 报销凭证界面。
 */
public class TicketMachineBlock extends class_2237 {
	public static final class_2753 FACING = class_2383.field_11177;
	public static final class_2746 UPPER = class_2746.method_11825("upper");

	private static final class_265 LOWER = class_2248.method_9541(0.0, 0.0, 3.0, 16.0, 16.0, 16.0);
	private static final class_265 UPPER_SHAPE = class_2248.method_9541(0.0, 0.0, 3.0, 16.0, 16.0, 16.0);

	public TicketMachineBlock(final class_2251 settings) {
		super(settings);
		method_9590(method_9564().method_11657(FACING, class_2350.field_11043).method_11657(UPPER, false));
	}

	@Override
	protected void method_9515(final class_2689.class_2690<class_2248, class_2680> builder) {
		builder.method_11667(FACING, UPPER);
	}

	@Override
	public class_2680 method_9605(final class_1750 ctx) {
		return method_9564().method_11657(FACING, ctx.method_8042().method_10153()).method_11657(UPPER, false);
	}

	@Override
	public boolean method_9558(final class_2680 state, final class_4538 world, final class_2338 pos) {
		if (state.method_11654(UPPER)) {
			return world.method_8320(pos.method_10074()).method_27852(this);
		}
		return world.method_8320(pos.method_10084()).method_26215() || world.method_8320(pos.method_10084()).method_27852(this);
	}

	@Override
	public class_2464 method_9604(final class_2680 state) {
		return class_2464.field_11458;
	}

	@Override
	public class_265 method_9530(final class_2680 state, final class_1922 world, final class_2338 pos,
			final class_3726 context) {
		return state.method_11654(UPPER) ? UPPER_SHAPE : LOWER;
	}

	@Nullable
	@Override
	public class_2586 method_10123(final class_2338 pos, final class_2680 state) {
		// 只有下半格带方块实体
		return state.method_11654(UPPER) ? null : new TicketMachineBlockEntity(pos, state);
	}

	@Override
	public void method_9567(final class_1937 world, final class_2338 pos, final class_2680 state, @Nullable final class_1309 placer,
			final class_1799 itemStack) {
		super.method_9567(world, pos, state, placer, itemStack);
		if (world.method_8608() || state.method_11654(UPPER)) {
			return;
		}
		if (world.method_8320(pos.method_10084()).method_26215()) {
			world.method_8652(pos.method_10084(), state.method_11657(UPPER, true), class_2248.field_31036);
		}
	}

	@Override
	public void method_9536(final class_2680 state, final class_1937 world, final class_2338 pos, final class_2680 newState,
			final boolean moved) {
		if (!world.method_8608() && !state.method_27852(newState.method_26204()) && !newState.method_27852(this)) {
			final class_2338 other = state.method_11654(UPPER) ? pos.method_10074() : pos.method_10084();
			if (world.method_8320(other).method_27852(this)) {
				world.method_8652(other, net.minecraft.class_2246.field_10124.method_9564(), class_2248.field_31036);
			}
		}
		super.method_9536(state, world, pos, newState, moved);
	}

	@Override
	public class_1269 method_9534(final class_2680 state, final class_1937 world, final class_2338 pos, final class_1657 player,
			final class_1268 hand, final class_3965 hit) {
		if (world.method_8608()) {
			return class_1269.field_5812;
		}
		if (!(player instanceof class_3222 serverPlayer) || !(world instanceof class_3218 serverWorld)) {
			return class_1269.field_5811;
		}
		final class_2338 lowerPos = state.method_11654(UPPER) ? pos.method_10074() : pos;
		if (!(world.method_8321(lowerPos) instanceof TicketMachineBlockEntity machine)) {
			return class_1269.field_5811;
		}
		com.mtr12306.net.ModNetworking.openMachine(serverPlayer, lowerPos, machine.stationId(serverWorld, lowerPos));
		serverPlayer.method_7353(class_2561.method_43470("§7售票机 · 可购票与打印报销凭证（需账号）"), true);
		return class_1269.field_5812;
	}
}
