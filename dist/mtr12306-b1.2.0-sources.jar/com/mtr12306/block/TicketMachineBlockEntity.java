package com.mtr12306.block;

import com.mtr12306.Mtr12306;
import com.mtr12306.TicketingManager;
import com.mtr12306.data.Station;
import com.mtr12306.mtr.MtrIntegration;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3218;

/**
 * 售票机方块实体：只负责判断自己属于哪个车站（按所在位置的 MTR 车站名匹配本系统车站）。
 */
public class TicketMachineBlockEntity extends class_2586 {
	public TicketMachineBlockEntity(final class_2338 pos, final class_2680 state) {
		super(ModBlocks.TICKET_MACHINE_ENTITY, pos, state);
	}

	@Override
	public void method_11007(final class_2487 nbt) {
		super.method_11007(nbt);
	}

	@Override
	public void method_11014(final class_2487 nbt) {
		super.method_11014(nbt);
	}

	@Override
	public class_2487 method_16887() {
		return method_38244();
	}

	/** 机器所属车站 id（识别不到时返回第一个车站，再不行返回空串） */
	public String stationId(final class_3218 world, final class_2338 pos) {
		final TicketingManager manager = Mtr12306.manager();
		if (manager == null) {
			return "";
		}
		final String mtrStation = MtrIntegration.stationNameAt(GateHelper.dimension(world), pos.method_10263(), pos.method_10264(),
				pos.method_10260());
		if (!mtrStation.isBlank()) {
			for (final Station station : manager.data().stations.values()) {
				if (station.name.equalsIgnoreCase(mtrStation) || station.mtrStation.equalsIgnoreCase(mtrStation)) {
					return station.id;
				}
			}
		}
		return manager.data().stations.isEmpty() ? "" : manager.data().stations.values().iterator().next().id;
	}
}
