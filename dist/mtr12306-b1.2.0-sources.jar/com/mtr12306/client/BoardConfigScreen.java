package com.mtr12306.client;

import com.mtr12306.net.ModNetworking;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** 车站大屏配置：车站 + 尺寸（宽×高，向右/向上扩展）+ 检票口多选（空=不限）。 */
public class BoardConfigScreen extends class_437 {
	private final class_2338 pos;
	private final String rightDirection;
	private final List<String[]> stations = new ArrayList<>();
	private final List<String[]> checkpoints = new ArrayList<>();
	private final Set<String> selected = new LinkedHashSet<>();
	private String stationId;
	private int boardWidth;
	private int boardHeight;
	private final int kind;

	public BoardConfigScreen(final class_2338 pos, final String stationId, final String rightDirection, final int width,
			final int height, final List<String[]> stations, final List<String[]> checkpoints,
			final List<String> selectedIds, final int kind) {
		super(class_2561.method_43470(kind == 1 ? "广播器配置" : "车站大屏配置"));
		this.pos = pos;
		this.stationId = stationId == null ? "" : stationId;
		this.rightDirection = rightDirection;
		this.boardWidth = Math.max(1, width);
		this.boardHeight = Math.max(1, height);
		this.stations.addAll(stations);
		this.checkpoints.addAll(checkpoints);
		this.selected.addAll(selectedIds);
		this.kind = kind;
		if (this.stationId.isEmpty() && !this.stations.isEmpty()) {
			this.stationId = this.stations.get(0)[0];
		}
	}

	private List<String[]> checkpointsOfStation() {
		final List<String[]> list = new ArrayList<>();
		for (final String[] cp : checkpoints) {
			if (cp[1].equals(stationId)) {
				list.add(cp);
			}
		}
		return list;
	}

	private String stationName() {
		for (final String[] station : stations) {
			if (station[0].equals(stationId)) {
				return station[1];
			}
		}
		return "未选择";
	}

	@Override
	protected void method_25426() {
		final int cx = field_22789 / 2;
		int y = 42;

		if (stations.size() > 1) {
			method_37063(class_4185.method_46430(class_2561.method_43470("车站：" + stationName()), button -> {
				int index = 0;
				for (int i = 0; i < stations.size(); i++) {
					if (stations.get(i)[0].equals(stationId)) {
						index = i;
					}
				}
				stationId = stations.get((index + 1) % stations.size())[0];
				selected.clear();
				method_41843();
			}).method_46434(cx - 150, y, 300, 20).method_46431());
			y += 24;
		}

		if (kind == 0) {
		method_37063(class_4185.method_46430(class_2561.method_43470("宽度：" + boardWidth + "（点击 +1）"), button -> {
			boardWidth = boardWidth >= 12 ? 1 : boardWidth + 1;
			button.method_25355(class_2561.method_43470("宽度：" + boardWidth + "（点击 +1）"));
		}).method_46434(cx - 150, y, 146, 20).method_46431());
		method_37063(class_4185.method_46430(class_2561.method_43470("高度：" + boardHeight + "（点击 +1）"), button -> {
			boardHeight = boardHeight >= 8 ? 1 : boardHeight + 1;
			button.method_25355(class_2561.method_43470("高度：" + boardHeight + "（点击 +1）"));
		}).method_46434(cx + 4, y, 146, 20).method_46431());
		y += 24;
		}

		method_37063(class_4185.method_46430(class_2561.method_43470("§e不限检票口（清空）"), button -> {
			selected.clear();
			method_41843();
		}).method_46434(cx - 150, y, 300, 20).method_46431());
		y += 24;

		int shown = 0;
		for (final String[] cp : checkpointsOfStation()) {
			if (shown >= 7) {
				break;
			}
			final boolean on = selected.contains(cp[0]);
			method_37063(class_4185.method_46430(class_2561.method_43470((on ? "§a✔ " : "§7") + cp[2]), button -> {
				if (selected.contains(cp[0])) {
					selected.remove(cp[0]);
				} else {
					selected.add(cp[0]);
				}
				method_41843();
			}).method_46434(cx - 150, y, 300, 20).method_46431());
			y += 22;
			shown++;
		}

		method_37063(class_4185.method_46430(class_2561.method_43470("§a保存"), button -> save())
				.method_46434(cx - 152, field_22790 - 28, 148, 20).method_46431());
		method_37063(class_4185.method_46430(class_2561.method_43470("§c取消"), button -> method_25419())
				.method_46434(cx + 4, field_22790 - 28, 148, 20).method_46431());
	}

	private void save() {
		final class_2540 buf = PacketByteBufs.create();
		buf.method_10807(pos);
		buf.method_10814(stationId);
		if (kind == 1) {
			buf.writeInt(selected.size());
			for (final String id : selected) {
				buf.method_10814(id);
			}
			ClientPlayNetworking.send(ModNetworking.BIND_BROADCAST, buf);
			method_25419();
			return;
		}
		buf.writeInt(boardWidth);
		buf.writeInt(boardHeight);
		buf.writeInt(selected.size());
		for (final String id : selected) {
			buf.method_10814(id);
		}
		ClientPlayNetworking.send(ModNetworking.BIND_BOARD, buf);
		method_25419();
	}

	@Override
	public void method_25394(final class_332 context, final int mouseX, final int mouseY, final float delta) {
		method_25420(context);
		context.method_27534(field_22793, field_22785, field_22789 / 2, 12, 0xFFFFFF);
		context.method_27534(field_22793,
				class_2561.method_43470("§7屏幕向右扩展方向：§f" + rightDirection + " §7（向上按高度堆叠）"), field_22789 / 2, 26, 0xAAAAAA);
		if (stations.size() <= 1) {
			context.method_27534(field_22793, class_2561.method_43470("§f车站：" + stationName()), field_22789 / 2, 44, 0xFFFFFF);
		}
		context.method_27534(field_22793, class_2561.method_43470((kind == 1 ? "§7检票口：" : "§7屏幕尺寸：§f"
				+ boardWidth + " × " + boardHeight + " §7｜检票口：") + (selected.isEmpty() ? "§e不限" : "§f" + selected.size() + " 个")),
				field_22789 / 2, field_22790 - 44, 0xFFFFFF);
		super.method_25394(context, mouseX, mouseY, delta);
	}

	@Override
	public boolean method_25421() {
		return false;
	}
}
