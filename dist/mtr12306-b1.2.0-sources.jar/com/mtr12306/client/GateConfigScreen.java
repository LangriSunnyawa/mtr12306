package com.mtr12306.client;

import com.mtr12306.net.ModNetworking;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * 闸机配置：选择所属车站（受闸机所在 MTR 车站限制）、多选检票口（不选 = 不限）、通行模式。
 */
public class GateConfigScreen extends class_437 {
	private static final String[] MODES = {"ENTRY", "EXIT", "BOTH", "TRANSFER", "VALIDATE"};
	private static final String[] MODE_NAMES = {"进站检票", "出站放行", "双向", "换乘", "车票核验"};

	private final class_2338 pos;
	private final String mtrStation;
	private final List<String[]> stations = new ArrayList<>();
	private final List<String[]> checkpoints = new ArrayList<>();
	private final Set<String> selected = new LinkedHashSet<>();
	private String stationId;
	private String mode;

	public GateConfigScreen(final class_2338 pos, final String stationId, final String mode, final String mtrStation,
			final List<String[]> stations, final List<String[]> checkpoints, final List<String> selectedIds) {
		super(class_2561.method_43470("闸机配置"));
		this.pos = pos;
		this.stationId = stationId == null ? "" : stationId;
		this.mode = mode == null || mode.isBlank() ? "ENTRY" : mode;
		this.mtrStation = mtrStation == null ? "" : mtrStation;
		this.stations.addAll(stations);
		this.checkpoints.addAll(checkpoints);
		this.selected.addAll(selectedIds);
		if (this.stationId.isEmpty() && !this.stations.isEmpty()) {
			this.stationId = this.stations.get(0)[0];
		}
	}

	private int modeIndex() {
		for (int i = 0; i < MODES.length; i++) {
			if (MODES[i].equals(mode)) {
				return i;
			}
		}
		return 0;
	}

	private List<String[]> checkpointsOfStation() {
		final List<String[]> list = new ArrayList<>();
		for (final String[] cp : checkpoints) {
			if (cp[1].equals(stationId)) {
				list.add(cp);
			}
		}
		return list;
	}

	@Override
	protected void method_25426() {
		final int cx = field_22789 / 2;
		int y = 44;

		// 车站（识别到 MTR 车站时只有一项）
		if (stations.size() > 1) {
			method_37063(class_4185.method_46430(class_2561.method_43470("车站：" + stationName()), button -> {
				int index = 0;
				for (int i = 0; i < stations.size(); i++) {
					if (stations.get(i)[0].equals(stationId)) {
						index = i;
					}
				}
				stationId = stations.get((index + 1) % stations.size())[0];
				selected.clear();
				method_41843();
			}).method_46434(cx - 150, y, 300, 20).method_46431());
		}
		y += 24;

		method_37063(class_4185.method_46430(class_2561.method_43470("通行模式：" + MODE_NAMES[modeIndex()]), button -> {
			mode = MODES[(modeIndex() + 1) % MODES.length];
			button.method_25355(class_2561.method_43470("通行模式：" + MODE_NAMES[modeIndex()]));
		}).method_46434(cx - 150, y, 300, 20).method_46431());
		y += 24;

		method_37063(class_4185.method_46430(class_2561.method_43470("§e不限检票口（清空选择）"), button -> {
			selected.clear();
			method_41843();
		}).method_46434(cx - 150, y, 300, 20).method_46431());
		y += 24;

		final List<String[]> list = checkpointsOfStation();
		int shown = 0;
		for (final String[] cp : list) {
			if (shown >= 8) {
				break;
			}
			final boolean on = selected.contains(cp[0]);
			method_37063(class_4185.method_46430(class_2561.method_43470((on ? "§a✔ " : "§7") + cp[2]), button -> {
				if (selected.contains(cp[0])) {
					selected.remove(cp[0]);
				} else {
					selected.add(cp[0]);
				}
				method_41843();
			}).method_46434(cx - 150, y, 300, 20).method_46431());
			y += 22;
			shown++;
		}

		method_37063(class_4185.method_46430(class_2561.method_43470("§a保存"), button -> save())
				.method_46434(cx - 152, field_22790 - 28, 148, 20).method_46431());
		method_37063(class_4185.method_46430(class_2561.method_43470("§c取消"), button -> method_25419())
				.method_46434(cx + 4, field_22790 - 28, 148, 20).method_46431());
	}

	private String stationName() {
		for (final String[] station : stations) {
			if (station[0].equals(stationId)) {
				return station[1];
			}
		}
		return "未选择";
	}

	private void save() {
		final class_2540 buf = PacketByteBufs.create();
		buf.method_10807(pos);
		buf.method_10814(stationId);
		buf.method_10814(mode);
		buf.writeInt(selected.size());
		for (final String id : selected) {
			buf.method_10814(id);
		}
		ClientPlayNetworking.send(ModNetworking.BIND_GATE, buf);
		method_25419();
	}

	@Override
	public void method_25394(final class_332 context, final int mouseX, final int mouseY, final float delta) {
		method_25420(context);
		context.method_27534(field_22793, field_22785, field_22789 / 2, 12, 0xFFFFFF);
		context.method_27534(field_22793,
				class_2561.method_43470("§7闸机 " + pos.method_10263() + ", " + pos.method_10264() + ", " + pos.method_10260() + "  §b"
						+ (mtrStation.isEmpty() ? "（未识别到 MTR 车站）" : "MTR 车站：" + mtrStation)), field_22789 / 2, 26, 0xAAAAAA);
		if (stations.size() <= 1) {
			context.method_27534(field_22793, class_2561.method_43470("§f车站：" + stationName()), field_22789 / 2, 46, 0xFFFFFF);
		}
		context.method_27534(field_22793,
				class_2561.method_43470("§7已选检票口：" + (selected.isEmpty() ? "§e不限" : "§f" + selected.size() + " 个")),
				field_22789 / 2, field_22790 - 44, 0xFFFFFF);
		super.method_25394(context, mouseX, mouseY, delta);
	}

	@Override
	public boolean method_25421() {
		return false;
	}
}
