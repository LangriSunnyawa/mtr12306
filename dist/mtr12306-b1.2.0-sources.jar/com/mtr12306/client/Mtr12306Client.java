package com.mtr12306.client;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mtr12306.net.ModNetworking;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import java.util.ArrayList;
import java.util.List;

public class Mtr12306Client implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		// 车站大屏渲染器
		net.minecraft.class_5616.method_32144(
				com.mtr12306.block.ModBlocks.STATION_BOARD_ENTITY,
				com.mtr12306.client.StationBoardRenderer::new);
		// 报销凭证：手持右键打开蓝票界面（客户端注入，服务端不会加载这些类）
		com.mtr12306.item.ItemReceipt.clientViewer = stack -> net.minecraft.class_310.method_1551()
				.method_1507(new ReceiptScreen(com.mtr12306.item.ItemReceipt.json(stack)));
		// 报销凭证的悬浮提示（只能在客户端注册，避免服务端加载客户端类）
		net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback.EVENT.register((stack, context, lines) -> {
			if (stack.method_7909() instanceof com.mtr12306.item.ItemReceipt) {
				final com.google.gson.JsonObject json = com.mtr12306.item.ItemReceipt.json(stack);
				if (json == null) {
					lines.add(class_2561.method_43470("§7未写入车票信息"));
					return;
				}
				lines.add(class_2561.method_43470("§7" + com.mtr12306.item.ItemReceipt.opt(json, "fromStation") + " → "
						+ com.mtr12306.item.ItemReceipt.opt(json, "toStation")));
				lines.add(class_2561.method_43470("§7" + com.mtr12306.item.ItemReceipt.opt(json, "fromTime") + " - "
						+ com.mtr12306.item.ItemReceipt.opt(json, "toTime") + " · "
						+ com.mtr12306.item.ItemReceipt.opt(json, "seatClass") + " "
						+ com.mtr12306.item.ItemReceipt.opt(json, "seat")));
				lines.add(class_2561.method_43470("§8票价 " + com.mtr12306.item.ItemReceipt.opt(json, "price") + " 元 · 票号 "
						+ com.mtr12306.item.ItemReceipt.opt(json, "ticketId")));
				lines.add(class_2561.method_43470("§9手持右键查看报销凭证"));
			}
		});

		ClientPlayNetworking.registerGlobalReceiver(ModNetworking.OPEN_GATE_CONFIG, (client, handler, buf, sender) -> {
			final class_2338 pos = buf.method_10811();
			final String stationId = buf.method_10800(32767);
			final String mode = buf.method_10800(16);
			final String mtrStation = buf.method_10800(32767);
			final List<String[]> stations = new ArrayList<>();
			final int stationCount = buf.readInt();
			for (int i = 0; i < stationCount; i++) {
				stations.add(new String[]{buf.method_10800(32767), buf.method_10800(32767)});
			}
			final List<String[]> checkpoints = new ArrayList<>();
			final int checkpointCount = buf.readInt();
			for (int i = 0; i < checkpointCount; i++) {
				checkpoints.add(new String[]{buf.method_10800(32767), buf.method_10800(32767), buf.method_10800(32767)});
			}
			final List<String> selected = new ArrayList<>();
			final int selectedCount = buf.readInt();
			for (int i = 0; i < selectedCount; i++) {
				selected.add(buf.method_10800(32767));
			}
			client.execute(() -> client.method_1507(
					new GateConfigScreen(pos, stationId, mode, mtrStation, stations, checkpoints, selected)));
		});

		ClientPlayNetworking.registerGlobalReceiver(ModNetworking.OPEN_BOARD_CONFIG, (client, handler, buf, sender) -> {
			final class_2338 pos = buf.method_10811();
			final int kind = buf.readByte();
			final String stationId = buf.method_10800(32767);
			final String rightDirection = buf.method_10800(16);
			final int width = buf.readInt();
			final int height = buf.readInt();
			final List<String[]> stations = new ArrayList<>();
			final int stationCount = buf.readInt();
			for (int i = 0; i < stationCount; i++) {
				stations.add(new String[]{buf.method_10800(32767), buf.method_10800(32767)});
			}
			final List<String[]> checkpoints = new ArrayList<>();
			final int checkpointCount = buf.readInt();
			for (int i = 0; i < checkpointCount; i++) {
				checkpoints.add(new String[]{buf.method_10800(32767), buf.method_10800(32767), buf.method_10800(32767)});
			}
			final List<String> selected = new ArrayList<>();
			final int selectedCount = buf.readInt();
			for (int i = 0; i < selectedCount; i++) {
				selected.add(buf.method_10800(32767));
			}
			client.execute(() -> client.method_1507(new BoardConfigScreen(pos, stationId, rightDirection, width, height,
					stations, checkpoints, selected, kind)));
		});

		ClientPlayNetworking.registerGlobalReceiver(ModNetworking.OPEN_MACHINE, (client, handler, buf, sender) -> {
			final class_2338 pos = buf.method_10811();
			final String json = buf.method_10800(1 << 20);
			client.execute(() -> {
				try {
					client.method_1507(new TicketMachineScreen(pos, JsonParser.parseString(json).getAsJsonObject()));
				} catch (Exception exception) {
					if (client.field_1724 != null) {
						client.field_1724.method_7353(class_2561.method_43470("§c售票机数据解析失败"), false);
					}
				}
			});
		});

		ClientPlayNetworking.registerGlobalReceiver(ModNetworking.MACHINE_RESULT, (client, handler, buf, sender) -> {
			final boolean success = buf.readBoolean();
			final String message = buf.method_10800(1 << 20);
			client.execute(() -> {
				TicketMachineScreen.lastResult = (success ? "§a" : "§c") + message;
				if (client.field_1724 != null) {
					client.field_1724.method_7353(class_2561.method_43470((success ? "§a" : "§c") + message), false);
				}
			});
		});
	}

	@SuppressWarnings("unused")
	private static JsonObject unused() {
		return new JsonObject();
	}
}
