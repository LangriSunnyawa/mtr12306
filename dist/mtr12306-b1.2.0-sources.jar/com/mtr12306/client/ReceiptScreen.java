package com.mtr12306.client;

import com.google.gson.JsonObject;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/**
 * 报销凭证界面：国铁蓝票样式，内容按车票信息即时渲染（不依赖固定贴图文本）。
 */
public class ReceiptScreen extends class_437 {
	// 国铁蓝票配色
	private static final int PAPER = 0xFFDCEBF8;
	private static final int PAPER_DARK = 0xFFC9DEF1;
	private static final int INK = 0xFF16233A;
	private static final int HEADER = 0xFF1B2B41;
	private static final int SEAL = 0xFFC8323C;

	private final JsonObject data;

	public ReceiptScreen(final JsonObject data) {
		super(class_2561.method_43470("报销凭证"));
		this.data = data == null ? new JsonObject() : data;
	}

	private String opt(final String key) {
		try {
			return data.has(key) && !data.get(key).isJsonNull() ? data.get(key).getAsString() : "";
		} catch (Exception e) {
			return "";
		}
	}

	@Override
	protected void method_25426() {
		method_37063(class_4185.method_46430(class_2561.method_43470("关闭"), button -> method_25419())
				.method_46434(field_22789 / 2 - 60, field_22790 - 34, 120, 20).method_46431());
	}

	@Override
	public void method_25394(final class_332 context, final int mouseX, final int mouseY, final float delta) {
		method_25420(context);
		final int w = Math.min(360, field_22789 - 40);
		final int h = 250;
		final int x = (field_22789 - w) / 2;
		final int y = Math.max(16, (field_22790 - h) / 2 - 10);

		// 纸张 + 抬头
		context.method_25294(x, y, x + w, y + h, PAPER);
		context.method_25294(x, y, x + w, y + 26, HEADER);
		context.method_25294(x, y + h - 46, x + w, y + h - 44, PAPER_DARK);
		context.method_49601(x, y, w, h, 0xFF8FA9C0);

		context.method_27535(field_22793, class_2561.method_43470("§f中国铁路 · 电子客票报销凭证"), x + 10, y + 8, 0xFFFFFF);
		context.method_27535(field_22793, class_2561.method_43470("§7" + opt("state")), x + w - 70, y + 8, 0xDDDDDD);

		int ty = y + 34;
		final String[][] rows = {
				{"车次", opt("service") + " 次", "乘车日期", opt("date")},
				{"出发站", opt("fromStation") + "  " + opt("fromTime"), "到达站", opt("toStation") + "  " + opt("toTime")},
				{"乘车人", opt("passenger"), "席位", opt("seatClass") + "  " + opt("seat")},
				{"票价", "￥" + opt("price"), "检票口", opt("checkpoint")},
				{"票号", opt("ticketId"), "账号", opt("account")},
		};
		for (final String[] row : rows) {
			context.method_27535(field_22793, class_2561.method_43470("§8" + row[0]), x + 12, ty, INK);
			context.method_27535(field_22793, class_2561.method_43470("§0" + row[1]), x + 58, ty, INK);
			context.method_27535(field_22793, class_2561.method_43470("§8" + row[2]), x + 200, ty, INK);
			context.method_27535(field_22793, class_2561.method_43470("§0" + row[3]), x + 244, ty, INK);
			ty += 18;
		}

		// 电子客票章（红色）
		final int cx = x + w - 52;
		final int cy = y + h - 40;
		context.method_25294(cx - 18, cy - 18, cx + 18, cy + 18, 0x00FFFFFF);
		context.method_49601(cx - 18, cy - 18, 36, 36, SEAL);
		context.method_49601(cx - 16, cy - 16, 32, 32, SEAL);
		context.method_27534(field_22793, class_2561.method_43470("§c电子"), cx, cy - 10, SEAL);
		context.method_27534(field_22793, class_2561.method_43470("§c客票"), cx, cy - 2, SEAL);
		context.method_27534(field_22793, class_2561.method_43470("§c章"), cx, cy + 6, SEAL);

		context.method_27535(field_22793, class_2561.method_43470("§7仅供报销使用 · 本凭证打印后车票不可退票"), x + 12, y + h - 38, 0x555555);
		context.method_27535(field_22793, class_2561.method_43470("§7开具时间 " + opt("printedAt")), x + 12, y + h - 24, 0x555555);
		super.method_25394(context, mouseX, mouseY, delta);
	}

	@Override
	public boolean method_25421() {
		return false;
	}
}
