package com.mtr12306.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mtr12306.block.ModBlocks;
import com.mtr12306.block.StationBoardBlock;
import com.mtr12306.block.StationBoardBlockEntity;
import net.minecraft.class_1921;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_827;
import org.joml.Matrix4f;

/**
 * 车站大屏渲染：只在锚点方块处绘制整块矩形画面（一次绘制，性能与普通方块持平）。
 */
public class StationBoardRenderer implements class_827<StationBoardBlockEntity> {
	private static final int BACKGROUND = 0xFF0A1018;
	private static final int HEADER_COLOR = 0xFFEAF2FF;
	private static final int ROW_COLOR = 0xFFB8CBE0;
	private static final int BOARDING_COLOR = 0xFF4CD964;

	/** 1.20.1 的 BER 工厂需要接收 Context 的构造器 */
	public StationBoardRenderer(final net.minecraft.class_5614.class_5615 context) {
	}

	@Override
	public void render(final StationBoardBlockEntity entity, final float tickDelta, final class_4587 matrices,
			final class_4597 vertexConsumers, final int light, final int overlay) {
		if (!entity.method_11010().method_11654(StationBoardBlock.MAIN)) {
			return;
		}
		final class_2487 nbt = entity.method_11010() == null ? null : null;
		final JsonObject payload = readPayload(entity);
		final int width = Math.max(1, payload.has("width") ? payload.get("width").getAsInt() : extractInt(entity, "w"));
		final int height = Math.max(1, payload.has("height") ? payload.get("height").getAsInt() : extractInt(entity, "h"));
		final JsonArray rows = payload.has("rows") ? payload.getAsJsonArray("rows") : new JsonArray();

		final class_2350 facing = entity.method_11010().method_11654(StationBoardBlock.FACING);
		final float yaw = switch (facing) {
			case field_11034 -> 90.0F;
			case field_11035 -> 180.0F;
			case field_11039 -> 270.0F;
			default -> 0.0F;
		};

		matrices.method_22903();
		// 以方块中心为轴做水平旋转，和 blockstate 的 y 旋转一致
		matrices.method_22904(0.5, 0.0, 0.5);
		matrices.method_22907(net.minecraft.class_7833.field_40716.rotationDegrees(yaw));
		matrices.method_22904(-0.5, 0.0, -0.5);

		final float w = width;
		final float h = height;
		final float z = 14.55F / 16.0F;

		// 背景板
		final Matrix4f matrix = matrices.method_23760().method_23761();
		final class_4588 solid = vertexConsumers.getBuffer(class_1921.method_23577());
		quad(solid, matrix, 0.02F, 0.02F, w - 0.02F, h - 0.02F, z, BACKGROUND, light);

		// 文本
		final class_327 textRenderer = class_310.method_1551().field_1772;
		matrices.method_22903();
		matrices.method_46416(0.0F, h - 0.02F, z + 0.001F);
		matrices.method_22905(1.0F / 16.0F, -1.0F / 16.0F, 1.0F / 16.0F);

		final String station = payload.has("station") ? payload.get("station").getAsString() : "";
		textRenderer.method_30882(class_2561.method_43470("站名 / 车次    开点   终到站    站台  状态"), 2.0F, 2.0F, HEADER_COLOR, false,
				matrices.method_23760().method_23761(), vertexConsumers, class_327.class_6415.field_33993, 0, light);

		int line = 0;
		for (int i = 0; i < rows.size(); i++) {
			final JsonObject row = rows.get(i).getAsJsonObject();
			final int y = 12 + line * 9;
			if (y > h * 16.0F - 8.0F) {
				break;
			}
			final boolean boarding = row.has("boarding") && row.get("boarding").getAsBoolean();
			final String text = str(row, "service") + "  " + str(row, "depart") + "  " + str(row, "toStation") + "  "
					+ str(row, "platform") + "  " + str(row, "status");
			textRenderer.method_30882(class_2561.method_43470(text), 2.0F, y, boarding ? BOARDING_COLOR : ROW_COLOR, false,
					matrices.method_23760().method_23761(), vertexConsumers, class_327.class_6415.field_33993, 0, light);
			line++;
		}
		if (rows.isEmpty()) {
			textRenderer.method_30882(class_2561.method_43470("暂无车次"), 2.0F, 12.0F, ROW_COLOR, false,
					matrices.method_23760().method_23761(), vertexConsumers, class_327.class_6415.field_33993, 0, light);
		}
		matrices.method_22909();
		matrices.method_22909();
	}

	private static String str(final JsonObject json, final String key) {
		try {
			return json.has(key) && !json.get(key).isJsonNull() ? json.get(key).getAsString() : "";
		} catch (Exception e) {
			return "";
		}
	}

	private static int extractInt(final StationBoardBlockEntity entity, final String key) {
		final class_2487 nbt = entity.method_38244();
		return Math.max(1, nbt.method_10550(key));
	}

	private static JsonObject readPayload(final StationBoardBlockEntity entity) {
		final class_2487 nbt = entity.method_38244();
		if (nbt.method_10545("payload")) {
			try {
				return JsonParser.parseString(nbt.method_10558("payload")).getAsJsonObject();
			} catch (Exception ignored) {
			}
		}
		return new JsonObject();
	}

	private static void quad(final class_4588 consumer, final Matrix4f matrix, final float x1, final float y1,
			final float x2, final float y2, final float z, final int color, final int light) {
		final int a = (color >>> 24) & 0xFF;
		final int r = (color >>> 16) & 0xFF;
		final int g = (color >>> 8) & 0xFF;
		final int b = color & 0xFF;
		consumer.method_22918(matrix, x1, y1, z).method_1336(r, g, b, a).method_22913(0.0F, 0.0F).method_22917(0, 10)
				.method_22916(light).method_22914(0.0F, 0.0F, -1.0F).method_1344();
		consumer.method_22918(matrix, x1, y2, z).method_1336(r, g, b, a).method_22913(0.0F, 1.0F).method_22917(0, 10)
				.method_22916(light).method_22914(0.0F, 0.0F, -1.0F).method_1344();
		consumer.method_22918(matrix, x2, y2, z).method_1336(r, g, b, a).method_22913(1.0F, 1.0F).method_22917(0, 10)
				.method_22916(light).method_22914(0.0F, 0.0F, -1.0F).method_1344();
		consumer.method_22918(matrix, x2, y1, z).method_1336(r, g, b, a).method_22913(1.0F, 0.0F).method_22917(0, 10)
				.method_22916(light).method_22914(0.0F, 0.0F, -1.0F).method_1344();
	}

	@Override
	public boolean rendersOutsideBoundingBox(final StationBoardBlockEntity entity) {
		return true;
	}

	@SuppressWarnings("unused")
	private static void unused() {
		ModBlocks.STATION_BOARD.toString();
	}
}
