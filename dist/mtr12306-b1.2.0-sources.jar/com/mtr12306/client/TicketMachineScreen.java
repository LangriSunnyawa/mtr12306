package com.mtr12306.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.mtr12306.net.ModNetworking;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import java.util.ArrayList;
import java.util.List;

/**
 * 售票机界面：购买车票（需要账号）+ 打印报销凭证。
 */
public class TicketMachineScreen extends class_437 {
	public static String lastResult = "";

	private final class_2338 pos;
	private final String station;
	private final List<JsonObject> services = new ArrayList<>();
	private final List<JsonObject> tickets = new ArrayList<>();

	public TicketMachineScreen(final class_2338 pos, final JsonObject payload) {
		super(class_2561.method_43470("售票机"));
		this.pos = pos;
		this.station = opt(payload, "station");
		final JsonArray serviceArray = payload.has("services") ? payload.getAsJsonArray("services") : new JsonArray();
		for (final JsonElement element : serviceArray) {
			services.add(element.getAsJsonObject());
		}
		final JsonArray ticketArray = payload.has("tickets") ? payload.getAsJsonArray("tickets") : new JsonArray();
		for (final JsonElement element : ticketArray) {
			tickets.add(element.getAsJsonObject());
		}
	}

	private static String opt(final JsonObject json, final String key) {
		try {
			return json != null && json.has(key) && !json.get(key).isJsonNull() ? json.get(key).getAsString() : "";
		} catch (Exception e) {
			return "";
		}
	}

	@Override
	protected void method_25426() {
		final int cx = field_22789 / 2;
		int y = 40;

		int row = 0;
		for (final JsonObject service : services) {
			if (row >= 6) {
				break;
			}
			final JsonArray classes = service.has("classes") ? service.getAsJsonArray("classes") : new JsonArray();
			if (classes.isEmpty()) {
				continue;
			}
			final JsonObject first = classes.get(0).getAsJsonObject();
			final String label = "§f" + opt(service, "service") + " §7" + opt(service, "depart") + " → "
					+ opt(first, "toStation") + " §e" + opt(first, "price") + " 元 §7(" + opt(first, "name")
					+ " 余 " + opt(first, "remaining") + ")";
			method_37063(class_4185.method_46430(class_2561.method_43470("购 " + label), button -> buy(service, first))
					.method_46434(cx - 200, y, 400, 20).method_46431());
			y += 22;
			row++;
		}

		y += 6;
		int t = 0;
		for (final JsonObject ticket : tickets) {
			if (t >= 6) {
				break;
			}
			final boolean printed = "true".equals(opt(ticket, "printed"));
			final String label = (printed ? "§8" : "§b") + "凭证 " + opt(ticket, "ticketId") + " §7"
					+ opt(ticket, "service") + " " + opt(ticket, "fromStation") + "→" + opt(ticket, "toStation")
					+ (printed ? " §8(已打印)" : "");
			method_37063(class_4185.method_46430(class_2561.method_43470(label), button -> print(ticket))
					.method_46434(cx - 200, y, 400, 20).method_46431());
			y += 22;
			t++;
		}

		method_37063(class_4185.method_46430(class_2561.method_43470("关闭"), button -> method_25419())
				.method_46434(cx - 60, field_22790 - 28, 120, 20).method_46431());
	}

	private void buy(final JsonObject service, final JsonObject seatClass) {
		final class_2540 buf = PacketByteBufs.create();
		buf.method_10807(pos);
		buf.method_10814(opt(service, "service"));
		buf.method_10814(opt(seatClass, "code"));
		buf.method_10814(opt(seatClass, "toStationId"));
		ClientPlayNetworking.send(ModNetworking.MACHINE_BUY, buf);
		lastResult = "§7正在购票…";
	}

	private void print(final JsonObject ticket) {
		if ("true".equals(opt(ticket, "printed"))) {
			lastResult = "§e该车票的报销凭证已打印过";
			return;
		}
		final class_2540 buf = PacketByteBufs.create();
		buf.method_10814(opt(ticket, "ticketId"));
		ClientPlayNetworking.send(ModNetworking.MACHINE_PRINT, buf);
		lastResult = "§7正在打印报销凭证…";
	}

	@Override
	public void method_25394(final class_332 context, final int mouseX, final int mouseY, final float delta) {
		method_25420(context);
		context.method_27534(field_22793, class_2561.method_43470("§l售票机 §r§7· " + station), field_22789 / 2, 14, 0xFFFFFF);
		context.method_27534(field_22793, class_2561.method_43470("§7上半部分：本站今日可售车次（点「购」即购票）"),
				field_22789 / 2, 26, 0xAAAAAA);
		if (!lastResult.isBlank()) {
			context.method_27534(field_22793, class_2561.method_43470(lastResult), field_22789 / 2, field_22790 - 44, 0xFFFF55);
		}
		super.method_25394(context, mouseX, mouseY, delta);
	}

	@Override
	public boolean method_25421() {
		return false;
	}
}
