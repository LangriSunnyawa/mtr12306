package com.mtr12306.item;

import com.mtr12306.block.TicketGateBlockEntity;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import org.jetbrains.annotations.Nullable;

/**
 * 闸机物品：放置时把闸机预设为指定通行模式（进站 / 出站 / 双向 / 换乘）。
 */
public class GateItem extends class_1747 {
	private final String mode;

	public GateItem(final class_2248 block, final class_1793 settings, final String mode) {
		super(block, settings);
		this.mode = mode;
	}

	public String mode() {
		return mode;
	}

	@Override
	protected boolean method_7710(final class_2338 pos, final class_1937 world, @Nullable final class_1657 player,
			final class_1799 stack, final class_2680 state) {
		final boolean result = super.method_7710(pos, world, player, stack, state);
		if (!world.method_8608() && world.method_8321(pos) instanceof TicketGateBlockEntity gate) {
			gate.setBinding(gate.stationId(), gate.checkpointIds(), mode);
			gate.syncBinding();
		}
		return result;
	}

	@Override
	public String method_7876() {
		return "item.mtr12306.ticket_gate_" + mode.toLowerCase();
	}
}
