package com.mtr12306.item;

import com.google.gson.JsonObject;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import org.jetbrains.annotations.Nullable;

/**
 * 报销凭证物品：NBT 里保存车票信息，手持右键打开"国铁蓝票"界面（内容即时渲染）。
 * 注意：本类不能直接引用任何 {@code net.minecraft.client.*} 类型，否则专用服务器会加载失败。
 */
public class ItemReceipt extends class_1792 {
	public static final String NBT_KEY = "ReceiptData";

	/** 由客户端初始化时注入：拿着凭证右键时打开蓝票界面 */
	public static java.util.function.Consumer<class_1799> clientViewer = null;

	public ItemReceipt(final class_1793 settings) {
		super(settings);
	}

	@Nullable
	public static String data(final class_1799 stack) {
		final class_2487 nbt = stack.method_7969();
		if (nbt == null || !nbt.method_10545(NBT_KEY)) {
			return null;
		}
		return nbt.method_10558(NBT_KEY);
	}

	public static JsonObject json(final class_1799 stack) {
		final String raw = data(stack);
		if (raw == null || raw.isBlank()) {
			return null;
		}
		try {
			return com.google.gson.JsonParser.parseString(raw).getAsJsonObject();
		} catch (Exception e) {
			return null;
		}
	}

	public static String opt(final JsonObject json, final String key) {
		try {
			return json != null && json.has(key) && !json.get(key).isJsonNull() ? json.get(key).getAsString() : "";
		} catch (Exception e) {
			return "";
		}
	}

	@Override
	public class_2561 method_7864(final class_1799 stack) {
		final JsonObject json = json(stack);
		if (json == null) {
			return class_2561.method_43471("item.mtr12306.receipt");
		}
		return class_2561.method_43470("报销凭证 · " + opt(json, "service") + " 次 " + opt(json, "date"));
	}

	@Override
	public boolean method_7886(final class_1799 stack) {
		return false;
	}

	@Override
	public class_1271<class_1799> method_7836(final class_1937 world, final class_1657 user, final class_1268 hand) {
		final class_1799 stack = user.method_5998(hand);
		if (world.field_9236 && clientViewer != null) {
			clientViewer.accept(stack);
		}
		return class_1271.method_22427(stack);
	}
}
