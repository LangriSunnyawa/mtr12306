package com.mtr12306.item;

import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

/**
 * 配置道具判定：MTR 原版的「刷子」({@code mtr:brush}) 与本模组的配置面板都可用来配置闸机/大屏/广播器。
 */
public final class ConfigTools {
	private static class_1792 mtrBrush = null;
	private static boolean resolved = false;

	private ConfigTools() {
	}

	public static boolean isConfigTool(final class_1799 stack) {
		if (stack == null || stack.method_7960()) {
			return false;
		}
		if (stack.method_7909() instanceof ConfigToolItem) {
			return true;
		}
		return stack.method_31574(mtrBrush());
	}

	private static class_1792 mtrBrush() {
		if (!resolved) {
			resolved = true;
			mtrBrush = class_7923.field_41178.method_10223(new class_2960("mtr", "brush"));
		}
		return mtrBrush;
	}
}
